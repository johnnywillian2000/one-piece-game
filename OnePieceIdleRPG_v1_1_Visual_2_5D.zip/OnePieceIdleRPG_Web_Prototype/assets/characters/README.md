# Sprites locais v0.9

SVGs vetoriais originais criados para esta primeira passagem visual. O Phaser os carrega durante `preload()` com tamanho de textura de 96×96. As poses são separadas para que ajustes futuros possam ser feitos sem reescrever a lógica de movimento ou combate.

- `hero_f_*`: protagonista de frente.
- `hero_b_*`: protagonista de costas.
- `hero_s_*`: protagonista de lado.
- `hero_s_windup.svg`, `hero_s_atk.svg`, `hero_s_recover.svg`: fases do soco.
- `hero_f_hurt.svg`: reação ao dano.
- `hero_f_victory.svg`: pose de comemoração usada ao subir de nível.
- `bandit_*`: inimigo comum.
- `boss_*`: variação de chefe.

Estes arquivos são arte própria do protótipo, não sprites extraídos de jogos comerciais.

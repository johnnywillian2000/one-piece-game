# v0.4 — Mochila, minimapa, navegação e refinamento visual

- Removido o painel permanente de inventário/rota para reduzir a poluição da tela.
- Criada janela de mochila com grade, raridade, comparação, detalhes e equipar/retirar.
- Criado minimapa visível com acesso ao mapa completo.
- Melhorado o editor de mapa: arrastar para marcar área; tocar para área rápida; toques sucessivos para pontos da rota.
- Implementada navegação A* em grade para contornar obstáculos no movimento manual e na caça automática.
- Spawn tenta evitar casas e árvores.
- Sprites provisórios redesenhados e detalhes de terreno/caminhos adicionados.
- Mantido o salvamento local da progressão e dos equipamentos.

Validação realizada: `node --check src/main.js` passou. Não foi possível concluir a instalação de dependências/build neste ambiente; teste a execução com `npm install` e `npm run dev` no seu PC.

# v0.3 — inventário e mapa de caça

- Inventário com botões Equipar e Retirar, comparação de atributo e quatro slots.
- Equipamentos modificam ataque, defesa, vida e crítico (crítico visualizado; cálculo de dano crítico ainda pendente).
- Salvamento local de inventário, equipamentos, nível, XP, KOs, rota e área de caça.
- Mapa completo da ilha acessível por botão; arraste para delimitar uma área de caça ou selecione rota por pontos.
- Caça automática prioriza mobs na área delimitada e patrulha a área quando não há alvos próximos.
- Visuais continuam provisórios. Navegação por obstáculos e equilíbrio de drops precisam de testes no navegador.

## Executar
Na pasta onde está package.json: npm install, depois npm run dev.

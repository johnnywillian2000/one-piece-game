# v0.9 — Visual Upgrade

## Recursos gráficos
- Adicionados 41 sprites SVG vetoriais para o protagonista, animações de movimento e golpe, inimigos comuns e o chefe.
- Adicionadas texturas de grama e quatro variantes de paralelepípedos em PNG para serem consumidas como arquivos de arte pelo Phaser.
- Adicionada uma folha de prévia dos assets (`assets/references/recursos_v09_preview.png`), identificada como prévia de recursos, não como captura do jogo.
- Retratos provisórios da mochila/ficha foram substituídos pelo sprite do protagonista.

## Animação e combate
- O protagonista usa escala de renderização maior com tamanho de corpo físico compensado.
- Criada a sequência visual de antecipação, extensão e recuperação do soco.
- O cálculo de dano, o número flutuante, o feedback de impacto e a pose de reação do inimigo agora ocorrem na janela visual do impacto (105 ms após o início do ataque).
- Reação do protagonista ao receber dano e pose curta de comemoração ao subir de nível.
- Inimigos e chefe usam sprites locais novos e mantêm os estados de repouso, caminhada e ataque.

## Sistemas preservados
- Mantidos os controles de teclado, clique/toque, joystick, navegação A*, colisões, caça automática, seleção de alvo, dano/HP/XP/níveis, spawn/respawn, drop de moedas/equipamentos, inventário, equipamento, venda automática, mapas/rotas e salvamento local.
- Estrutura do projeto mantida em Phaser 3.90, JavaScript ES Modules e Vite 6.

## Testes e limitações
- Aprovado: `node --check src/main.js`.
- Aprovado: `node --check src/sprites.js`.
- Aprovado: validação XML dos SVGs e conferência de existência das 41 texturas carregadas + 5 texturas PNG.
- Aprovado: `npm run test:assets`.
- Pendente: `npm run build`; a tentativa de instalar dependências atingiu o tempo limite e Vite não estava disponível no ambiente.
- Pendente: teste visual do jogo no navegador, testes de movimento/colisão e medição de desempenho em execução real.

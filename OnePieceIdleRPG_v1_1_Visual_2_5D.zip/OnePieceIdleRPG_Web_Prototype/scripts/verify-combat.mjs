import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = dirname(dirname(fileURLToPath(import.meta.url)));
const main = readFileSync(join(root, 'src', 'main.js'), 'utf8');
const css = readFileSync(join(root, 'src', 'style.css'), 'utf8');
const sprites = readFileSync(join(root, 'src', 'sprites.js'), 'utf8');

const checks = [
  ['lista de batalha', main.includes('id="battlepanel"') && main.includes('id="battlelist"')],
  ['seleção de alvo por clique', main.includes('findEnemyAt') && main.includes('selectTarget')],
  ['IDs únicos antes do primeiro spawn', main.indexOf('this.nextEnemyId=1;') >= 0 && main.indexOf('this.nextEnemyId=1;') < main.indexOf('this.regions.forEach((r,ri)=>')],
  ['soco com janela de impacto', main.includes("damage(e,this.player.atk") && main.includes("punchFx(e,n,onImpact=()=>{},style='basic')")],
  ['habilidade em área Bazuca', main.includes('applyBazucaDamage') && main.includes('bazucaWave')],
  ['multi-hit Gatling', main.includes('gatling()') && main.includes('quickStrikeFx')],
  ['ataque inimigo com antecipação sincronizada', main.includes('enemyAttack(e)') && main.includes('const windup=e.boss?430:360') && sprites.includes('hero_s_bazuca')],
  ['hotbar Q e 1', main.includes("keydown-Q") && main.includes('KeyCodes.ONE')],
  ['estilos do painel de batalha', css.includes('#battlepanel') && css.includes('.battle-row.selected')],
  ['efeitos SVG próprios de golpe/impacto', main.includes('fx_slash_blue') && main.includes('fx_impact_star')],
  ['profundidade de cena baseada no Y', main.includes('worldDepth(p.y+23)') && main.includes('worldDepth(e.y+(e.boss?29:20))')],
  ['barras visuais de HP e XP', main.includes('id=\"hpfill\"') && main.includes('id=\"xpfill\"') && css.includes('.meter-track')],
  ['antiga lógica de dano instantâneo removida', !main.includes('if(d<30&&this.time.now-e.lastHit>1000)')],
];
let failed = 0;
for (const [name, ok] of checks) { console.log(`${ok ? 'OK' : 'FALHOU'}: ${name}`); if (!ok) failed++; }
if (failed) { console.error(`${failed} verificação(ões) falharam.`); process.exitCode = 1; }
else console.log(`OK: ${checks.length} verificações estáticas de combate passaram.`);

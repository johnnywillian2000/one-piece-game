import { existsSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const failures = [];
const required = [];
for (const view of ['f', 'b', 's']) {
  for (const pose of ['i0', 'i1', 'w0', 'w1', 'w2', 'w3']) required.push(`hero_${view}_${pose}.svg`);
}
required.push('hero_s_windup.svg', 'hero_s_atk.svg', 'hero_s_recover.svg', 'hero_f_hurt.svg', 'hero_f_victory.svg');
for (const kind of ['bandit', 'boss']) {
  for (const pose of ['i0', 'i1', 'w0', 'w1', 'w2', 'w3', 'a0', 'a1', 'hit']) required.push(`${kind}_${pose}.svg`);
}
for (const file of required) {
  if (!existsSync(join(root, 'assets', 'characters', file))) failures.push(`Faltando assets/characters/${file}`);
}
for (const file of ['grass_base.png', 'cobblestone.png', 'cobblestone_v2.png', 'cobblestone_v3.png', 'cobblestone_v4.png']) {
  if (!existsSync(join(root, 'assets', 'tiles', file))) failures.push(`Faltando assets/tiles/${file}`);
}
const environment = ['palm.svg','tree_broadleaf.svg','bush_flower.svg','rock_cluster.svg','barrel.svg','crate.svg','camp_tent.svg','bonfire.svg','fern.svg','house_cabin.svg','house_shop.svg','house_inn.svg'];
for (const file of environment) {
  const path = join(root, 'assets', 'environment', file);
  if (!existsSync(path)) { failures.push(`Faltando assets/environment/${file}`); continue; }
  const svg = readFileSync(path, 'utf8');
  if (!svg.includes('<svg') || !svg.includes('viewBox=') || !svg.includes('</svg>')) failures.push(`SVG inválido ou sem viewBox: assets/environment/${file}`);
}
for (const file of ['slash_blue.svg','impact_star.svg']) {
  const path = join(root, 'assets', 'effects', file);
  if (!existsSync(path)) { failures.push(`Faltando assets/effects/${file}`); continue; }
  const svg = readFileSync(path, 'utf8');
  if (!svg.includes('<svg') || !svg.includes('viewBox=') || !svg.includes('</svg>')) failures.push(`SVG inválido ou sem viewBox: assets/effects/${file}`);
}
const main = readFileSync(join(root, 'src', 'main.js'), 'utf8');
for (const token of ['assets/environment/palm.svg','assets/environment/house_cabin.svg','assets/effects/slash_blue.svg','assets/effects/impact_star.svg']) {
  // The loader composes paths from the manifest, so check the directory and manifest entries together.
  const expected = token.split('/').pop().replace('.svg','');
  if (!main.includes(expected)) failures.push(`Recurso gráfico não referenciado: ${token}`);
}
const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));
if (pkg.dependencies?.phaser !== '^3.90.0') failures.push('A dependência Phaser não corresponde à versão esperada ^3.90.0');
if (!pkg.scripts?.build) failures.push('Script de build do Vite ausente no package.json');
if (failures.length) {
  console.error(`FALHOU: ${failures.length} verificação(ões)`);
  for (const item of failures) console.error(`- ${item}`);
  process.exitCode = 1;
} else {
  console.log(`OK: ${required.length} sprites de personagem, 5 texturas PNG, ${environment.length} assets de cenário e 2 efeitos vetoriais.`);
  console.log(`OK: Phaser ${pkg.dependencies.phaser}; script de build presente.`);
}

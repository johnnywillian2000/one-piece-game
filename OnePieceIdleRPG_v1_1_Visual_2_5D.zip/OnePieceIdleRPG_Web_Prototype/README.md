# One Piece Idle RPG — Ilha Dawn (v1.1 Visual 2.5D)

Protótipo web em **Phaser 3.90 + JavaScript ES Modules + Vite 6**. Esta etapa atualiza a apresentação do cenário e dos efeitos diretamente no projeto, sem substituir o mapa jogável por uma imagem estática nem remover a base de combate existente.

## Novidades da v1.1

- Casas trocadas por assets SVG locais independentes: cabana, comércio com toldo e bar/pousada.
- 12 assets de ambiente vetoriais: palmeira, árvore de copa, arbusto florido, samambaia, rochas, barril, caixa, tenda, fogueira e casas.
- Vegetação reposicionada como sprites com sombras, variação de escala e profundidade baseada no ponto de apoio, permitindo que o personagem passe visualmente atrás ou à frente conforme a posição.
- Movimento ambiental discreto na folhagem e na fogueira.
- Rastros de ataque e impacto por arquivos SVG próprios.
- Interface com barras de HP/XP, painéis refinados e maior contraste visual.
- Melhor escala visual e ajuste independente do corpo físico de protagonista e inimigos.

## Sistemas preservados

O projeto mantém Vila Foosha, floresta e acampamento, movimentação por teclado/clique/toque, navegação A*, colisões, caça automática, seleção de alvos, ataques, XP, níveis, morte com perda de XP, respawn, drops, inventário, equipamentos, venda automática, árvore visual de habilidades, mapa/minimapa, rotas e salvamento local.

## Recursos gráficos

- `assets/characters/`: sprites SVG de protagonista, bandidos e chefe.
- `assets/environment/`: assets vetoriais independentes de cenário.
- `assets/effects/`: rastro de golpe e impacto.
- `assets/tiles/`: texturas raster de grama e paralelepípedos usadas no mapa.
- `assets/references/visuais_v11_preview.png`: folha de prévia dos novos objetos e efeitos; **não é uma captura do jogo em funcionamento**.
- `assets/references/recursos_v09_preview.png`: prévia anterior dos recursos de personagem.

## Executar no Windows

1. Extraia o ZIP.
2. Entre na pasta `OnePieceIdleRPG_Web_Prototype`.
3. Na barra de endereço do Explorador de Arquivos, digite `cmd` e pressione Enter.
4. Execute:

```bash
npm install
npm run test:assets
npm run test:combat
npm run dev
```

5. Abra o endereço local mostrado pelo Vite.

Para gerar a versão de produção, execute `npm run build` depois de instalar as dependências.

## Controles

- WASD/setas: mover.
- Clique/toque no cenário: caminhar usando desvio de obstáculos.
- Espaço: soco básico.
- Q: Gomu Gomu no Bazuca, com dano em área frontal.
- 1: Gomu Gomu no Gatling, quatro impactos rápidos.
- Clique em um inimigo: selecionar e perseguir; também é possível selecionar pelo painel de batalha.
- E: ligar/desligar a caça automática.
- Mochila: inventário e equipamentos.
- Mapa: definir área de caça ou desenhar rota.

## Testes e limitações

Verificações executadas: `node --check src/main.js`, `node --check src/sprites.js`, `npm run test:assets`, `npm run test:combat` e exportação dos SVGs com Inkscape. A tentativa de `npm install` excedeu o limite de tempo deste ambiente, portanto `npm run build` não foi concluído e o jogo não foi declarado visualmente validado em navegador. Depois de iniciar localmente, confira a posição dos pés, a oclusão dos objetos, o alinhamento das colisões e o fluxo de caça automática.

Os assets novos são arte vetorial original criada para esta etapa; não foram extraídos arquivos, ROMs ou sprites de jogos comerciais.

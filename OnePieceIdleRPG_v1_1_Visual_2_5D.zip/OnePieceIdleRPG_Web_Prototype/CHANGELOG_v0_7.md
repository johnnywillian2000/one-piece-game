# v0.7 — Animações do mapa e dos personagens (Ilha Dawn / Vila Foosha)

## Personagem (estilo Luffy)
- Sprites novos com 3 direções (frente, costas, lado) e ciclo de caminhada de 4 frames; respiração parada (idle).
- Chapéu de palha com fita vermelha, cicatriz sob o olho, cicatriz em X no peito, colete aberto.
- Sombra no chão, poeirinha ao andar, tremor e flash vermelho ao apanhar.
- **Gomu Gomu no Pistola**: o braço estica até o inimigo e volta (soco normal e crítico; o crítico/golpe especial é maior, com "DON!/BAM!/POW!" e tremor de tela). Impacto em estrela e empurrão no inimigo.
- Efeito de nível: anel de luz, brilhos e texto "NÍVEL UP!".

## Inimigos
- Bandidos com idle, caminhada e ataque (clava levantada); viram para o jogador.
- Chefe **Higuma** (nome em `BOSS_NAME`, `src/sprites.js`): gola de pele, cicatriz, 30% maior, nome e barra de vida dourada.
- Barra de vida aparece quando o bandido é ferido; sombra no chão; aparecem numa nuvenzinha de poeira.
- Ao serem derrotados, voam pelos ares girando e somem num brilho ✦ (clássico de One Piece).
- Moedas giram e quicam; piscam antes de sumir.

## Mapa
- Mar com 2 camadas de ondas deslizando e espuma que vai e volta com a maré; gaivotas sobrevoando.
- Enseada no porto com ondulações; o barco balança e a vela ondula.
- **Moinho de vento de Foosha** (a "Vila do Moinho") com pás girando, e placa balançando do **Party's Bar**.
- Chaminés com fumaça; bandeiras ao vento no porto (azul) e no acampamento (vermelha com caveira).
- Fogueira do acampamento com chamas tremulando, brilho pulsante, faíscas e fumaça.
- Copas das árvores balançando; ~120 tufos de capim balançando fora das trilhas; folhas voando na floresta.
- Sombras de nuvens atravessando a ilha.

## Técnico
- Novo arquivo `src/sprites.js` (sprites e animações geradas por código, sem imagens).
- Mudanças em `src/main.js`: `animateMap`, `updateFx`, `punchFx`, `killFx`, etc. (procure por "v0.7").
- Mecânicas, dados e salvamento não foram alterados.

## Testes
- `node --check` e um teste de fumaça com Phaser simulado (create + métodos de efeito) passaram.
- **Ainda não foi aberto em navegador** (sem acesso a `npm install` aqui): vale conferir visualmente o movimento, a posição do moinho e a enseada do porto.

# v0.8 — acabamento visual e direção de arte

- Refinada a camada visual CSS com painéis de maior profundidade, hierarquia, contraste, estados de interação e foco acessível.
- Adicionada referência conceitual original para orientar a futura produção de assets.
- Atualizada a documentação para distinguir claramente conceito visual de arte já integrada ao jogo.
- Mantidas as mecânicas da v0.7 sem alteração intencional.
- Próxima prioridade recomendada: substituir sprites procedurais por spritesheets autorais e tilesets coerentes, validando primeiro uma vertical slice pequena de Vila Foosha.

# v1.0 — Protótipo de combate estilo MMORPG top-down

## Referência de design pesquisada

A organização dos controles e da lista de batalha toma como referência os padrões documentados no [guia público do otPiece](https://otpiece.com/guide) e sua [lista de habilidades](https://otpiece.com/ability) (seleção de criaturas, caminhada por clique/setas e habilidades individuais com efeitos distintos). A ideia de dar uma animação própria para cada ataque foi orientada também por descrições públicas de [Grand Line Adventures](https://xtibia.com/en/forum/topic/240253-arquivado-grand-line-adventures/). Todos os efeitos e comportamentos implementados nesta versão são originais; não foram extraídos sprites, ROMs ou animações dos jogos citados.

## Implementado

- Painel de batalha com os alvos mais próximos, HP, nível e indicador de alvo selecionado.
- Seleção de inimigos pelo clique no personagem ou na lista de batalha; aproximação automática do alvo selecionado fora de alcance.
- Hotbar persistente com soco (Espaço), Bazuca em área (Q) e Gatling multi-hit (1).
- Bazuca aplica dano em cone frontal, com onda visual própria e dano reduzido aos inimigos secundários.
- Gatling gera quatro impactos rápidos com pequenas diferenças visuais.
- Ataques de bandido e chefe têm preparação, janela de impacto e recuperação; o dano só é aplicado se o protagonista ainda estiver ao alcance no momento do impacto.
- O modo de caça automática pode usar a Bazuca quando há mais de um inimigo por perto.
- Marcador visual de alvo e barras de vida mantidos no mundo do jogo.
- Preservados os sistemas já existentes de navegação A*, movimentação por teclado/clique/joystick, regiões, respawn, chefe Higuma, XP, níveis, morte com perda de XP, drops, inventário, equipamentos, venda automática, minimapa, rotas e salvamento local.

## Escopo do mapa

O mapa Ilha Dawn da versão anterior foi preservado nesta etapa. A mudança principal é o fluxo de combate e a interface de seleção de alvos; a substituição completa do cenário por um tileset Tibia-like será uma etapa separada, assim que a referência de mapa for definida.

## Testes

- `node --check src/main.js`: aprovado.
- `node --check src/sprites.js`: aprovado.
- `npm run test:assets`: aprovado.
- `npm run test:combat`: verificação estática do novo fluxo de batalha.
- `npm run build`: não concluído neste ambiente porque `npm install` excedeu o limite de tempo; o protótipo não foi declarado como validado no navegador.

## Controles

- WASD/setas: movimentar.
- Clique no cenário: caminhar com navegação A*.
- Clique no inimigo: selecionar; se estiver longe, aproximar-se para atacar.
- Espaço: soco básico.
- Q: Gomu Gomu no Bazuca (dano em área frontal).
- 1: Gomu Gomu no Gatling (quatro impactos rápidos).
- E: ligar/desligar caça automática.

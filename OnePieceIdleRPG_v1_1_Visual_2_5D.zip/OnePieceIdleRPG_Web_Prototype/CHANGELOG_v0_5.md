# v0.5 — Equipamentos, venda e ficha do personagem

- Corrigido o problema principal ao equipar: as funções `equipItem` e `unequip` estavam ausentes na versão anterior.
- Equipar remove o item da mochila e coloca o equipamento anterior de volta no inventário.
- Adicionada venda manual do item selecionado, com recompensa em moedas.
- Adicionada configuração de venda automática: ligar/desligar e escolher raridades individualmente.
- Itens equipados não são vendidos automaticamente; a venda automática só se aplica a novos drops selecionados.
- Configurações de venda e moedas são salvas localmente.
- Adicionada tela de personagem com nível, vida, ataque, defesa, crítico, XP, moedas e inimigos derrotados.
- Adicionada prévia visual da futura árvore de habilidades passivas, ainda sem efeitos de jogo ativos.
- Refinados os detalhes ambientais do mapa por meio de vegetação baixa, pedras e flores.
- Incluída uma referência conceitual de direção visual; ela não é usada como textura dentro do jogo.

## Testes
- `node --check src/main.js`: aprovado.
- Build completo do Vite: depende da instalação das dependências no computador (`npm install`).

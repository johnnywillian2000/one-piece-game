# v1.1 — Visual 2.5D: cenário em assets e apresentação de combate

## Implementado

- Substituição das casas desenhadas com retângulos e triângulos por três assets SVG próprios: cabana, comércio com toldo e bar/pousada.
- Criação de assets SVG de cenário para palmeira, árvore de copa, arbusto florido, samambaia, rochas, barril, caixa, tenda e fogueira.
- Vegetação da floresta passou a usar sprites locais independentes em vez de centenas de círculos e elipses na camada de desenho estática.
- Objetos de cenário recebem profundidade com base na posição do ponto de apoio no chão; o protagonista, inimigos e sombras passam a usar o mesmo critério de ordenação Y.
- Adicionados movimentos ambientais muito sutis na vegetação e na fogueira.
- Ataques corpo a corpo passaram a usar um asset SVG de rastro com variações de direção; o impacto usa um asset próprio, ampliado para golpes fortes.
- Interface superior ganhou barras reais de HP e XP, melhor hierarquia de contraste, vinheta de cena e acabamento adicional de painéis e botões.
- Preservada a lógica de navegação A*, os corpos de colisão de obstáculos do mapa, combate, experiência, níveis, drops, inventário, equipamentos, mapa/minimapa, caça automática e salvamento local.

## Recursos adicionados

- `assets/environment/`: 12 assets vetoriais independentes.
- `assets/effects/`: rastro de golpe e impacto.
- `assets/references/visuais_v11_preview.png`: prévia dos assets adicionados; **não é captura do jogo em execução**.

## Verificações

- `node --check src/main.js`: aprovado.
- `node --check src/sprites.js`: aprovado.
- `npm run test:assets`: aprovado, incluindo os novos caminhos locais.
- `npm run test:combat`: aprovado, com verificações estáticas adicionais para efeitos, ordenação Y e barras HP/XP.
- Validação de renderização dos novos SVGs com Inkscape: os 14 recursos exportaram sem erro.
- `npm install` excedeu o limite de tempo do ambiente; por isso, `npm run build` não pôde ser completado. A cena ainda precisa ser executada no navegador para validação de alinhamento visual e colisões em tempo real.

## Limitações conhecidas

- A direção 2.5D é uma etapa de transição: casas e vegetação agora usam assets separados, mas as regiões, caminhos e alguns elementos de infraestrutura ainda são desenhados pelo Phaser.
- Os personagens continuam sendo sprites vetoriais estilizados do protótipo anterior; a próxima prioridade é uma folha de animação de personagem com mais quadros e expressividade e uma revisão em navegador.
- Os objetos decorativos da vegetação são posicionados aleatoriamente a cada nova execução, embora a navegação preserve as áreas de combate e as rotas gerais.

# v0.6 — Primeira etapa visual: cenário da Ilha Dawn

- Refeito o desenho procedural do mapa com camadas de terreno, costa, água e areia.
- Ruas com bordas e detalhes de pedras individuais.
- Casas com sombras, fundação, telhados com linhas de telhas, janelas e portas.
- Porto com píer, barco, postes e caixas.
- Árvores em camadas, arbustos, flores e rochas.
- Acampamento com paliçada, tendas, fogueira e barris.
- Mantidas as regiões de farm e os retângulos de colisão integrados ao cenário.

Esta é uma evolução da arte provisória feita em código, não ainda o mapa final pintado como a referência. Próxima etapa visual: converter o cenário em tilesets/spritesheets próprios e revisar colisões visualmente no navegador.

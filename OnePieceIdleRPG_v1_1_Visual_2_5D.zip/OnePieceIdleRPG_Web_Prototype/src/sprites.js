// v0.7 — Sprites procedurais (pixel-art) com frames de animação.
// Tudo é desenhado com retângulos para manter o visual pixelado e não depender de arquivos de imagem.
export const BOSS_NAME = 'Higuma'; // chefe dos bandidos da Floresta do Monte Colubo (troque o nome aqui)

const C = {
  ol: 0x17251c, skin: 0xe9b887, skinD: 0xc4915f, hair: 0x241812,
  vest: 0xb92722, vestD: 0x8c1c19, sash: 0xf0d45c, sashD: 0xc4a63c,
  shorts: 0x2c5b83, shortsD: 0x1f4363, hat: 0xf4cc54, hatH: 0xffe58a, hatD: 0xc79a35,
  band: 0xc0332b, sandal: 0x4a3220, eye: 0x241b16, mouth: 0x6e3326, scar: 0xa8553f
};

// ---------- HERÓI (estilo Luffy: chapéu de palha, colete vermelho, faixa amarela, shorts azul) ----------
function hatPixels(R, d, dx = 0) {
  R(C.hat, 8 + dx, 0 + d, 16, 5); R(C.hatH, 9 + dx, 1 + d, 12, 1);
  R(C.band, 8 + dx, 3 + d, 16, 2);
  R(C.hat, 4 + dx, 5 + d, 24, 2); R(C.hatD, 5 + dx, 7 + d, 22, 1);
}

function heroLegsFront(R, ll, rl) {
  const leg = (x, l) => {
    R(C.shorts, x, 32, 7, 4); R(C.shortsD, x, 35, 7, 1);
    const sh = 2 - l; if (sh > 0) R(C.skin, x + 1, 36, 5, sh);
    R(C.sandal, x - 1, 36 + sh, 9, 2);
  };
  leg(8, ll); leg(18, rl);
}

function heroFront(R, o, back) {
  const d = o.dy || 0, la = o.la || 0, ra = o.ra || 0;
  heroLegsFront(R, o.ll || 0, o.rl || 0);
  R(C.ol, 7, 5 + d, 18, 12); R(C.ol, 5, 15 + d, 22, 17);
  const arm = (x, a) => { R(C.ol, x - 1, 18 + d + a, 6, 13); R(C.skin, x, 19 + d + a, 4, 11); R(C.skinD, x + 3, 19 + d + a, 1, 11); };
  arm(2, la); arm(26, ra);
  if (!back) {
    R(C.hair, 9, 6 + d, 14, 8);
    R(C.skin, 9, 9 + d, 14, 12); R(C.skin, 7, 12 + d, 3, 6); R(C.skin, 22, 12 + d, 3, 6);
    R(C.eye, 12, 14 + d, 2, 3); R(C.eye, 19, 14 + d, 2, 3); R(C.scar, 19, 17 + d, 3, 1);
    R(C.mouth, 13, 18 + d, 7, 1); R(0xffffff, 14, 19 + d, 5, 1);
    R(C.vest, 7, 21 + d, 18, 10); R(C.skin, 14, 21 + d, 4, 8);
    R(C.scar, 15, 24 + d, 1, 1); R(C.scar, 16, 25 + d, 1, 1); R(C.scar, 16, 24 + d, 1, 1); R(C.scar, 15, 25 + d, 1, 1);
    R(C.vestD, 7, 21 + d, 1, 9); R(C.vestD, 24, 21 + d, 1, 9);
  } else {
    R(C.hair, 9, 6 + d, 14, 13); R(C.skin, 12, 19 + d, 8, 2);
    R(C.vestD, 7, 21 + d, 18, 10); R(C.vest, 9, 22 + d, 14, 8);
    R(0x8d6a3a, 12, 12 + d, 8, 2); // fio do chapéu de palha nas costas
  }
  R(C.sash, 7, 29 + d, 18, 3); R(C.sashD, 7, 31 + d, 18, 1);
  hatPixels(R, d);
}

function heroSide(R, o) {
  const d = o.dy || 0, dx = o.dx || 0, s = o.s || 0, a = o.arm || 0;
  const leg = (x, l) => {
    R(C.shorts, x, 32, 6, 4); R(C.shortsD, x, 35, 6, 1);
    const sh = 2 - l; if (sh > 0) R(C.skin, x, 36, 5, sh);
    R(C.sandal, x, 36 + sh, 8, 2);
  };
  leg(11 - s, o.ll || 0); leg(16 + s, o.rl || 0);
  // braço de trás
  if (!o.atk) { R(C.ol, 10 - a, 18 + d, 6, 13); R(C.skinD, 11 - a, 19 + d, 4, 11); }
  else { R(C.ol, 6, 18 + d, 6, 13); R(C.skinD, 7, 19 + d, 4, 11); }
  // corpo
  R(C.ol, 9 + dx, 5 + d, 15, 12); R(C.ol, 8 + dx, 15 + d, 16, 17);
  R(C.hair, 10 + dx, 7 + d, 6, 10);
  R(C.skin, 14 + dx, 9 + d, 10, 12); R(C.skin, 13 + dx, 12 + d, 3, 5);
  R(C.skin, 24 + dx, 14 + d, 1, 3);
  R(C.eye, 20 + dx, 14 + d, 2, 3); R(C.scar, 20 + dx, 17 + d, 3, 1);
  R(C.mouth, 20 + dx, 19 + d, 4, 1); R(0xffffff, 21 + dx, 20 + d, 2, 1);
  R(C.vest, 10 + dx, 21 + d, 14, 10); R(C.vestD, 10 + dx, 21 + d, 2, 10);
  R(C.skin, 22 + dx, 21 + d, 2, 8);
  R(C.sash, 10 + dx, 29 + d, 14, 3); R(C.sashD, 10 + dx, 31 + d, 14, 1);
  // braço da frente (some no soco: o braço esticado é desenhado como efeito)
  if (!o.atk) { R(C.ol, 14 + a, 18 + d, 6, 13); R(C.skin, 15 + a, 19 + d, 4, 11); R(C.skinD, 15 + a, 19 + d, 1, 11); }
  hatPixels(R, d, dx);
}

const HERO_POSES = {
  i0: {}, i1: { dy: 1 },
  w0: { ll: 2, la: 1, ra: -1 }, w1: { dy: 1 }, w2: { rl: 2, la: -1, ra: 1 }, w3: { dy: 1 }
};
const HERO_SIDE_POSES = {
  i0: { s: 0 }, i1: { s: 0, dy: 1 },
  w0: { s: 3, arm: -3 }, w1: { s: 0, dy: 1, ll: 2, arm: 0 }, w2: { s: -3, arm: 3 }, w3: { s: 0, dy: 1, rl: 2, arm: 0 }
};

// ---------- BANDIDOS (família da montanha) e CHEFE ----------
const BP = {
  bandit: { skin: 0xcaa07b, hair: 0x3d271d, band: 0x9e4932, vest: 0x596b3e, vestL: 0x79844b, belt: 0x4c3324, pants: 0x4a3a2c, boots: 0x30251d },
  boss: { skin: 0xb98558, hair: 0x4a3220, band: 0x6b4a2e, vest: 0x5a3a2a, vestL: 0x7b5338, belt: 0x2f221a, pants: 0x3a2f2a, boots: 0x241b16 }
};

function bandit(R, o, kind) {
  const p = BP[kind], d = o.dy || 0, la = o.la || 0, ra = o.ra || 0;
  // pernas
  const leg = (x, l) => { R(p.pants, x, 35, 7, 3); R(p.boots, x - 1, 38 - l, 9, 3); };
  leg(8, o.ll || 0); leg(18, o.rl || 0);
  R(C.ol, 7, 5 + d, 18, 18); R(C.ol, 4, 21 + d, 24, 14);
  // braços
  const arm = (x, a) => { R(C.ol, x - 1, 22 + d + a, 6, 13); R(p.skin, x, 23 + d + a, 4, 10); };
  arm(1, la); arm(27, ra);
  // clava na mão direita (levantada no ataque)
  const club = o.club;
  if (club === 'up') { R(C.ol, 27, 4 + d, 6, 24); R(0x8a5a33, 28, 5 + d, 4, 22); R(0xb98350, 28, 5 + d, 2, 22); R(0x5d3a20, 27, 3 + d, 6, 6); }
  else if (club === 'swing') { R(C.ol, 24, 20 + d, 8, 20); R(0x8a5a33, 25, 21 + d, 6, 18); R(0xb98350, 25, 21 + d, 2, 18); R(0x5d3a20, 24, 34 + d, 8, 6); }
  else { R(C.ol, 28, 18 + d + ra, 5, 20); R(0x8a5a33, 29, 19 + d + ra, 3, 18); R(0xb98350, 29, 19 + d + ra, 1, 18); R(0x5d3a20, 28, 32 + d + ra, 5, 5); }
  // cabeça
  R(p.hair, 8, 5 + d, 16, 7);
  R(p.skin, 9, 10 + d, 14, 12); R(p.skin, 7, 13 + d, 3, 5); R(p.skin, 22, 13 + d, 3, 5);
  const angry = club === 'up' || club === 'swing';
  R(C.eye, 12, 14 + d, 2, angry ? 1 : 2); R(C.eye, 19, 14 + d, 2, angry ? 1 : 2);
  if (angry) { R(C.eye, 11, 13 + d, 4, 1); R(C.eye, 18, 13 + d, 4, 1); R(C.mouth, 13, 18 + d, 7, 2); R(0xffffff, 14, 18 + d, 5, 1); }
  else { R(C.mouth, 14, 18 + d, 5, 1); }
  R(p.band, 7, 7 + d, 18, 3); R(p.band, 21, 8 + d, 5, 2); R(p.band, 25, 10 + d, 2, 3);
  // colete e cinto
  R(p.vest, 5, 22 + d, 22, 11); R(p.vestL, 8, 23 + d, 6, 7); R(p.vestL, 18, 23 + d, 6, 7);
  R(p.belt, 6, 32 + d, 20, 3); R(0xd3b66b, 14, 32 + d, 4, 3);
  if (kind === 'boss') {
    // gola de pele de urso e cicatriz — chefe da montanha
    R(0x6b4a2e, 3, 20 + d, 26, 5); R(0x8a6440, 5, 20 + d, 22, 2); R(0x4a3220, 3, 24 + d, 26, 1);
    R(0x4a3220, 8, 2 + d, 16, 5); R(0x6b4a2e, 9, 3 + d, 14, 2); R(0x8a6440, 7, 1 + d, 4, 3); R(0x8a6440, 21, 1 + d, 4, 3);
    R(0x8a3b2a, 20, 12 + d, 1, 6); R(0x8a3b2a, 19, 14 + d, 3, 1);
  }
}

const BANDIT_POSES = {
  i0: {}, i1: { dy: 1 },
  w0: { ll: 2, la: 1, ra: -1 }, w1: { dy: 1 }, w2: { rl: 2, la: -1, ra: 1 }, w3: { dy: 1 },
  a0: { club: 'up', dy: 0 }, a1: { club: 'swing', dy: 1 }
};

// ---------- gerador de texturas ----------
export function buildSprites(scene) {
  const g = scene.make.graphics({ x: 0, y: 0, add: false });
  const R = (c, x, y, w, h, a = 1) => { g.fillStyle(c, a); g.fillRect(x, y, w, h); };
  const make = (key, w, h, fn) => { if (scene.textures.exists(key)) return; fn(); g.generateTexture(key, w, h); g.clear(); };

  // herói: f = frente, b = costas, s = lado (virado para a direita; espelhado via flipX)
  for (const [k, o] of Object.entries(HERO_POSES)) {
    make('hero_f_' + k, 32, 40, () => heroFront(R, o, false));
    make('hero_b_' + k, 32, 40, () => heroFront(R, o, true));
  }
  for (const [k, o] of Object.entries(HERO_SIDE_POSES)) make('hero_s_' + k, 32, 40, () => heroSide(R, o));
  make('hero_s_atk', 32, 40, () => heroSide(R, { atk: true, s: 3, dx: 3, ll: 0, rl: 0 }));

  for (const kind of ['bandit', 'boss']) {
    for (const [k, o] of Object.entries(BANDIT_POSES)) make(kind + '_' + k, 36, 42, () => bandit(R, o, kind));
  }

  // moeda girando
  make('coin_1', 14, 14, () => { g.fillStyle(0xffd34f); g.fillEllipse(7, 7, 9, 12); g.fillStyle(0xfff1a0); g.fillRect(5, 3, 2, 2); });
  make('coin_2', 14, 14, () => { g.fillStyle(0xc99a2c); g.fillEllipse(7, 7, 4, 12); g.fillStyle(0xffd34f); g.fillRect(6, 3, 1, 8); });

  // efeitos
  make('shadow', 32, 12, () => { g.fillStyle(0x000000, 1); g.fillEllipse(16, 6, 30, 10); });
  make('glow', 128, 128, () => { for (let i = 0; i < 16; i++) { g.fillStyle(0xffa640, 0.04); g.fillCircle(64, 64, 64 - i * 4); } });
  make('smoke', 32, 32, () => { for (let i = 0; i < 6; i++) { g.fillStyle(0xe6e6e6, 0.11); g.fillCircle(16, 16, 15 - i * 2.2); } });
  make('puff', 10, 10, () => { g.fillStyle(0xf4efe0, 1); g.fillCircle(5, 5, 4); });
  make('spark', 4, 4, () => { g.fillStyle(0xffd45a, 1); g.fillRect(0, 0, 4, 4); g.fillStyle(0xfff3b0, 1); g.fillRect(1, 1, 2, 2); });
  make('leaf', 8, 6, () => { g.fillStyle(0xffffff, 1); g.fillEllipse(4, 3, 7, 4); });
  make('sparkle', 16, 16, () => {
    g.fillStyle(0xffffff, 1);
    g.fillPoints([{ x: 8, y: 0 }, { x: 10, y: 6 }, { x: 16, y: 8 }, { x: 10, y: 10 }, { x: 8, y: 16 }, { x: 6, y: 10 }, { x: 0, y: 8 }, { x: 6, y: 6 }], true);
  });
  make('impact', 44, 44, () => {
    const star = (r1, r2, c) => { const pts = []; for (let i = 0; i < 16; i++) { const a = i * Math.PI / 8, r = i % 2 ? r2 : r1; pts.push({ x: 22 + Math.cos(a) * r, y: 22 + Math.sin(a) * r }); } g.fillStyle(c, 1); g.fillPoints(pts, true); };
    star(21, 9, 0xd2562b); star(18, 8, 0xffe36e); star(11, 5, 0xffffff);
  });
  make('ring', 64, 64, () => { g.lineStyle(4, 0xffe9a0, 1); g.strokeCircle(32, 32, 28); g.lineStyle(2, 0xffffff, 0.8); g.strokeCircle(32, 32, 24); });
  make('ripple', 40, 14, () => { g.lineStyle(2, 0xd8f6f4, 0.9); g.strokeEllipse(20, 7, 36, 10); });
  make('cloud', 520, 260, () => {
    const blob = (cx, cy, w, h) => { for (let k = 0; k < 7; k++) { g.fillStyle(0x0b1e2d, 0.045); g.fillEllipse(cx, cy, w - k * w * 0.12, h - k * h * 0.12); } };
    blob(260, 130, 500, 230); blob(150, 150, 300, 160); blob(380, 110, 300, 150);
  });
  make('tuft', 12, 10, () => {
    R(0x3f7a3c, 1, 5, 1, 5); R(0x3f7a3c, 5, 2, 1, 8); R(0x3f7a3c, 9, 4, 1, 6);
    R(0x6aa44f, 3, 4, 1, 6); R(0x6aa44f, 7, 6, 1, 4); R(0x86bd62, 5, 2, 1, 3); R(0x86bd62, 1, 5, 1, 2);
  });
  make('gull0', 18, 10, () => {
    R(0xf5f5f0, 7, 5, 5, 2); R(0xf5f5f0, 12, 4, 2, 2); R(0xe8a23a, 14, 5, 2, 1);
    R(0xf5f5f0, 4, 3, 4, 2); R(0xf5f5f0, 2, 2, 3, 1); R(0xdcdcd4, 0, 1, 3, 1); R(0xdcdcd4, 8, 3, 3, 1);
  });
  make('gull1', 18, 10, () => {
    R(0xf5f5f0, 7, 3, 5, 2); R(0xf5f5f0, 12, 2, 2, 2); R(0xe8a23a, 14, 3, 2, 1);
    R(0xf5f5f0, 4, 5, 4, 2); R(0xf5f5f0, 2, 7, 3, 1); R(0xdcdcd4, 0, 8, 3, 1); R(0xdcdcd4, 8, 5, 3, 1);
  });
  make('wave', 96, 40, () => {
    let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    for (let i = 0; i < 16; i++) {
      const w = 8 + Math.floor(rnd() * 12), x = Math.floor(rnd() * (96 - w)), y = Math.floor(rnd() * 38);
      R(0xc9f1f0, x, y, w, 2, 0.5); R(0xc9f1f0, x + 3, y + 2, Math.max(2, w - 6), 1, 0.3);
    }
  });
  make('foam', 128, 18, () => {
    for (let x = 0; x <= 128; x += 16) {
      const y = 6 + Math.sin(x / 128 * Math.PI * 4) * 3;
      g.fillStyle(0xffffff, 0.85); g.fillEllipse(x, y, 26, 8);
      g.fillStyle(0xeaf8f6, 0.5); g.fillEllipse(x + 8, y + 5, 20, 5);
    }
  });
  g.destroy();

  // ---------- animações ----------
  const A = scene.anims;
  const add = (key, frames, frameRate, repeat = -1) => { if (!A.exists(key)) A.create({ key, frames: frames.map(f => ({ key: f })), frameRate, repeat }); };
  for (const v of ['f', 'b', 's']) {
    add(`hero_${v}_idle`, [`hero_${v}_i0`, `hero_${v}_i1`], 2.2);
    add(`hero_${v}_walk`, [`hero_${v}_w0`, `hero_${v}_w1`, `hero_${v}_w2`, `hero_${v}_w3`], 9);
  }
  for (const kind of ['bandit', 'boss']) {
    add(`${kind}_idle`, [`${kind}_i0`, `${kind}_i1`], 2);
    add(`${kind}_walk`, [`${kind}_w0`, `${kind}_w1`, `${kind}_w2`, `${kind}_w3`], 8);
    add(`${kind}_atk`, [`${kind}_a0`, `${kind}_a0`, `${kind}_a1`, `${kind}_a0`], 6);
  }
  add('hero_s_attack', ['hero_s_windup', 'hero_s_atk', 'hero_s_recover'], 16, 0);
  add('hero_s_bazuca', ['hero_s_windup', 'hero_s_windup', 'hero_s_atk', 'hero_s_recover'], 10, 0);
  add('hero_f_victory_anim', ['hero_f_victory'], 1, 0);
  add('coin_spin', ['coin', 'coin_1', 'coin_2', 'coin_1'], 8);
  add('gull_fly', ['gull0', 'gull1'], 4);
}

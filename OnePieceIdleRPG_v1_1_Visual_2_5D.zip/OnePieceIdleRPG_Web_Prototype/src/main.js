import Phaser from 'phaser';
import './style.css';
import {buildSprites,BOSS_NAME} from './sprites.js';

const WW=3000, WH=2200;
// Profundidade em pequenos degraus para manter a oclusão Y sem forçar ordenação a cada frame.
const worldDepth=(y)=>10+Math.floor(y/12)*.01;
const shadowDepth=(y)=>9.5+Math.floor(y/12)*.01;
class Island extends Phaser.Scene {
  constructor(){super('Island')}
  preload(){
    // Recursos vetoriais originais carregados como texturas locais; a lógica do jogo continua no Phaser.
    const heroFrames=[];
    for(const view of ['f','b','s']) for(const pose of ['i0','i1','w0','w1','w2','w3']) heroFrames.push(`hero_${view}_${pose}`);
    heroFrames.push('hero_s_windup','hero_s_atk','hero_s_recover','hero_f_hurt','hero_f_victory');
    for(const key of heroFrames) this.load.svg(key, `assets/characters/${key}.svg`, {width:96,height:96});
    for(const kind of ['bandit','boss']) for(const pose of ['i0','i1','w0','w1','w2','w3','a0','a1','hit']) {
      const key=`${kind}_${pose}`; this.load.svg(key, `assets/characters/${key}.svg`, {width:96,height:96});
    }
    this.load.image('terrain_grass','assets/tiles/grass_base.png');
    for(let i=0;i<4;i++){const suffix=i===0?'':`_v${i+1}`;this.load.image(`terrain_cobble_${i}`,`assets/tiles/cobblestone${suffix}.png`);}
    // Assets vetoriais de cenário: imagens locais independentes, com profundidade baseada no ponto de apoio.
    const environmentAssets=[['env_palm','palm',176,196],['env_tree','tree_broadleaf',164,174],['env_bush','bush_flower',128,94],['env_rock','rock_cluster',112,78],['env_barrel','barrel',76,88],['env_crate','crate',88,80],['env_tent','camp_tent',172,132],['env_bonfire','bonfire',100,112],['env_fern','fern',124,100],['env_house','house_cabin',200,178],['env_shop','house_shop',220,190],['env_inn','house_inn',224,190]];
    for(const [key,file,w,h] of environmentAssets)this.load.svg(key,`assets/environment/${file}.svg`,{width:w,height:h});
    this.load.svg('fx_slash_blue','assets/effects/slash_blue.svg',{width:160,height:112});
    this.load.svg('fx_impact_star','assets/effects/impact_star.svg',{width:104,height:104});
  }
  create(){
    this.physics.world.setBounds(0,0,WW,WH);
    this.cameras.main.setBounds(0,0,WW,WH);
    this.makeSprites();
    this.drawMap();
    this.animateMap();
    this.obstacles=this.physics.add.staticGroup();
    for(const r of this.rects){const o=this.obstacles.create(r.x,r.y,'block').setVisible(false);o.setDisplaySize(r.w,r.h).refreshBody();}
    this.buildNavigationGrid();
    this.player=this.physics.add.sprite(410,490,'hero_f_i0').setDepth(10).setCollideWorldBounds(true).setScale(.66).setSize(38,30).setOffset(29,56);
    this.player.hp=100;this.player.maxHp=100;this.player.level=1;this.player.xp=0;this.player.nextXp=100;this.player.atk=12;this.initPlayerFx();
    this.cameras.main.startFollow(this.player,true,.09,.09);
    this.cursors=this.input.keyboard.createCursorKeys();this.keys=this.input.keyboard.addKeys('W,A,S,D,SPACE,E');
    this.enemies=this.physics.add.group();this.drops=this.physics.add.group();
    this.regions=[
      {name:'Vila Foosha',x1:170,y1:300,x2:700,y2:680,cap:7,respawn:3500,level:1,boss:false},
      {name:'Floresta do Monte Colubo',x1:820,y1:400,x2:1800,y2:1500,cap:16,respawn:2800,level:2,boss:false},
      {name:'Acampamento dos Bandidos',x1:1980,y1:1120,x2:2400,y2:1450,cap:9,respawn:4200,level:3,boss:true}
    ];
    this.nextEnemyId=1;
    this.regions.forEach((r,ri)=>{r.index=ri;r.spawnAt=0;r.bossAlive=false;const initial=r.cap-(ri===2?1:0);for(let i=0;i<initial;i++)this.spawnInRegion(r,false);});
    this.inventory=[];this.equipped={};this.selectedItem=null;this.autoSell={enabled:false,rarities:['Comum']};this.passiveSkills={};this.huntArea=null;this.mapMode='area';this.route=[];this.routeIndex=0;this.routeEditing=false;this.routeTarget=null;this.routeName='Minha rota';
    try{const saved=JSON.parse(localStorage.getItem('dawnFarmRoute')||'null');if(saved?.points?.length){this.route=saved.points;this.routeName=saved.name||this.routeName;}}catch(e){}
    this.loadProgress();this.applyEquipment();this.physics.add.collider(this.player,this.obstacles);
    this.physics.add.collider(this.enemies,this.obstacles);
    this.physics.add.overlap(this.player,this.drops,(p,d)=>{d.destroy();this.toast('+1 moeda');});
    this.moveTarget=null;this.auto=false;this.lastAttack=0;this.skillReadyAt=0;this.gatlingReadyAt=0;this.selectedEnemy=null;this.lastBattleRender=0;
    this.keyOne=this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ONE);
    this.input.on('pointerdown',p=>{if(p.event?.target!==this.game.canvas)return;if(p.y<this.scale.height-90){const w=this.cameras.main.getWorldPoint(p.x,p.y);const clicked=this.findEnemyAt(w.x,w.y,38);if(clicked){this.selectTarget(clicked);const d=Phaser.Math.Distance.Between(this.player.x,this.player.y,clicked.x,clicked.y);if(d<=78){this.chaseTarget=null;this.moveTarget=null;this.attack();}else if(!this.auto){this.chaseTarget=clicked;this.setMoveTarget(clicked.x,clicked.y);}return;}if(!this.auto){this.chaseTarget=null;this.setMoveTarget(w.x,w.y);}}});
    this.input.keyboard.on('keydown-SPACE',()=>this.attack());
    this.input.keyboard.on('keydown-Q',()=>this.skill());this.input.keyboard.on('keydown-E',()=>this.toggleAuto());this.input.keyboard.on('keydown-ESC',()=>{if(this.hud){this.hud.querySelector('#mapmodal').hidden=true;this.hud.querySelector('#backpackmodal').hidden=true;this.hud.querySelector('#charactermodal').hidden=true;this.hud.querySelector('#settingsmodal').hidden=true;}});
    this.makeHUD();this.drawRoute();this.updateRouteInfo();this.renderInventory();this.renderEquipment();this.renderMap();
    this.scale.on('resize',()=>this.cameras.main.setZoom(this.zoom()));
    this.cameras.main.setZoom(this.zoom());
  }
  makeSprites(){
    const g=this.make.graphics({x:0,y:0,add:false});
    g.fillStyle(0x65452b);g.fillRect(0,0,24,24);g.generateTexture('block',24,24);g.clear();g.fillStyle(0xffd34f);g.fillCircle(7,7,6);g.fillStyle(0xfff1a0);g.fillRect(5,3,3,2);g.generateTexture('coin',14,14);g.destroy();
    buildSprites(this); // v0.9: animações usam sprites locais carregados no preload; efeitos e fallbacks seguem no Phaser
  }
  drawMap(){
    // Ilha Dawn v0.6: cenário em camadas, com porto, ruas de pedra, casas e vegetação.
    const g=this.add.graphics().setDepth(-10);this.roadGraphics=this.add.graphics().setDepth(-10.7);this.chimneys=[];this.flagDefs=[];this.signs=[];this.environmentProps=[];
    // Textura de grama desenhada como recurso SVG local, em vez de milhares de formas de chão geradas na cena.
    this.add.tileSprite(0,0,WW,WH,'terrain_grass').setOrigin(0,0).setDepth(-11).setTileScale(1.05);
    // Mar costeiro e faixa de areia no norte/oeste, com espuma.
    g.fillStyle(0x187f9a);g.fillRect(0,0,WW,160);
    g.fillStyle(0x279db0);g.fillRect(0,105,WW,62);
    for(let i=0;i<170;i++){const x=Math.random()*WW,y=10+Math.random()*145;g.lineStyle(1+Math.random()*2,0x76d4d2,0.4);g.beginPath();g.moveTo(x,y);g.lineTo(x+12+Math.random()*35,y+Math.random()*3);g.strokePath();}
    g.fillStyle(0xe9d6a2);g.fillRect(0,150,WW,90);
    for(let i=0;i<120;i++){const x=Math.random()*WW,y=158+Math.random()*72;g.fillStyle(i%2?0xf4e5bb:0xd5c28d,0.45);g.fillEllipse(x,y,5+Math.random()*14,2+Math.random()*5);}
    // Praça e ruas com borda escura, miolo de pedra e pedras individuais.
    const road=(points,width)=>{
      (this.roadLines=this.roadLines||[]).push({pts:points,w:width});const rg=this.roadGraphics;
      rg.lineStyle(width+12,0x66533d,1);rg.beginPath();rg.moveTo(points[0][0],points[0][1]);points.slice(1).forEach(p=>rg.lineTo(p[0],p[1]));rg.strokePath();
      rg.lineStyle(width,0xc6b184,1);rg.beginPath();rg.moveTo(points[0][0],points[0][1]);points.slice(1).forEach(p=>rg.lineTo(p[0],p[1]));rg.strokePath();
      // Cada trecho recebe uma textura de pedras real em arquivo PNG; a lógica de navegação segue usando a mesma rota.
      for(let i=0;i<points.length-1;i++){
        const [x1,y1]=points[i],[x2,y2]=points[i+1],dx=x2-x1,dy=y2-y1,d=Math.hypot(dx,dy),tileSize=width-2;
        const textureKey=`terrain_cobble_${(i+Math.round(width/2))%4}`;const piece=this.add.tileSprite((x1+x2)/2,(y1+y2)/2,d+8,tileSize,textureKey).setOrigin(.5).setRotation(Math.atan2(dy,dx)).setDepth(-10.6).setTileScale(tileSize/192);
        piece.setAlpha(.97);
      }
    };
    road([[70,500],[360,500],[560,540],[760,710],[1010,720],[1240,900],[1530,930],[1810,1060],[2130,1260],[2450,1430]],76);
    road([[550,535],[640,410],[850,350],[1040,380],[1210,520],[1240,900]],58);
    road([[1240,900],[1190,1120],[1330,1320],[1590,1420],[1780,1570]],54);
    road([[1810,1060],[1950,1120],[2100,1200],[2290,1210]],52);
    // Pequenas praças de terra batida.
    g.fillStyle(0xbca475);g.fillEllipse(410,500,280,170);g.fillStyle(0xd1bd8d);g.fillEllipse(410,496,245,135);
    this.rects=[];
    const addWorldProp=(key,x,y,scale=1,options={})=>{
      const sx=Array.isArray(scale)?scale[0]:scale,sy=Array.isArray(scale)?scale[1]:scale;
      const sprite=this.add.image(x,y,key).setOrigin(options.originX??.5,options.originY??1).setScale(sx,sy).setDepth(worldDepth(y));
      sprite.setAlpha(options.alpha??1);
      this.environmentProps.push({key,sprite,groundY:y,scaleX:sx,scaleY:sy,sway:!!options.sway});
      return sprite;
    };
    this.addWorldProp=addWorldProp;
    const label=(x,y,t)=>this.add.text(x,y,t,{fontFamily:'Trebuchet MS, sans-serif',fontSize:'24px',fontStyle:'bold',color:'#fff1c7',stroke:'#293b2b',strokeThickness:5}).setDepth(1);
    label(240,330,'VILA FOOSHA');label(1080,590,'FLORESTA DO MONTE COLUBO');label(1980,1080,'ACAMPAMENTO DOS BANDIDOS');
    // Casas como assets 2.5D detalhados. O sprite é ordenado pelo ponto de apoio no chão.
    const house=(x,y,w,h,wall=0xc98b50,roof=0x9f4432)=>{
      let key='env_house';
      if(x===720||x===1060)key='env_shop';
      if(x===900)key='env_inn';
      const dims=key==='env_shop'?[220,190]:key==='env_inn'?[224,190]:[200,178];
      const sx=(w+38)/dims[0],sy=(h+53)/dims[1];
      addWorldProp(key,x+w/2,y+h+6,[sx,sy]);
      this.rects.push({x:x+w/2,y:y+h/2,w:w-10,h:h-12});
      this.chimneys.push({x:x+w*.7+5,y:y-18});
    };
    house(230,390,100,75,0xc98a51,0xa54331);house(370,365,86,66,0xd0b16d,0x6f7546);house(250,535,92,70,0xb77749,0x9a4030);house(465,535,80,64,0xe0c28a,0x8e4c32);
    house(720,315,116,82,0xc68b54,0xa64a35);house(900,385,98,70,0xd6b879,0x98432f);house(1060,460,110,78,0xb9824f,0x7b7041);
    // Enseada do porto: água onde o barco flutua e o píer entra.
    g.fillStyle(0xcdb98a);g.fillEllipse(160,202,308,146);g.fillStyle(0x2a9fb3);g.fillEllipse(160,202,288,128);g.fillStyle(0x34b3c2);g.fillEllipse(160,198,250,104);
    // Moinho de vento — Foosha é a "Vila do Moinho". Torre estática aqui; as pás giram em animateMap.
    this.windmill={x:530,y:338};g.fillStyle(0x253528,0.32);g.fillEllipse(544,404,96,26);
    g.fillStyle(0xd9cdb0);g.fillPoints([{x:503,y:402},{x:557,y:402},{x:547,y:340},{x:513,y:340}],true);g.fillStyle(0xb9ac8e);g.fillPoints([{x:533,y:402},{x:557,y:402},{x:547,y:340},{x:533,y:340}],true);
    g.lineStyle(1,0x9a8d72,.7);for(let yy=352;yy<400;yy+=12){const k=(402-yy)*.1613;g.beginPath();g.moveTo(503+k,yy);g.lineTo(557-k,yy);g.strokePath();}
    g.fillStyle(0x69402a);g.fillRect(522,382,16,20);g.fillStyle(0x8dd0d0);g.fillRect(526,358,8,9);g.lineStyle(1,0x4c3828);g.strokeRect(526,358,8,9);
    g.fillStyle(0x6a3b2b);g.fillTriangle(506,344,554,344,530,308);g.fillStyle(0x9a4030);g.fillTriangle(509,342,551,342,530,311);
    this.rects.push({x:530,y:388,w:58,h:30});
    this.signs.push({x:505,y:549,text:"PARTY'S BAR"});
    // Porto, píer, barcos e caixas.
    g.fillStyle(0x6a5033);g.fillRect(0,245,300,40);g.fillStyle(0x9b7546);g.fillRect(0,250,300,12);g.fillRect(0,273,300,8);
    for(let x=18;x<300;x+=36){g.fillStyle(0x5a422d);g.fillRect(x,238,8,55);g.fillStyle(0xc19a5e);g.fillRect(x+1,238,6,6);}
    // O barco agora é um objeto animado (veja animateMap).
    for(const [x,y] of [[90,285],[125,292],[265,288],[300,315],[605,580],[650,590],[1160,610],[1870,1090],[1910,1100]]){g.fillStyle(0x67462e);g.fillRect(x,y,28,25);g.lineStyle(2,0xb28a50);g.strokeRect(x,y,28,25);g.lineStyle(1,0x4b3424);g.beginPath();g.moveTo(x,y+12);g.lineTo(x+28,y+12);g.strokePath();}
    // Árvores e vegetação em arquivos SVG, com sombras, volume e oclusão baseada no Y.
    const tree=(x,y,r=24)=>{
      const coastal=x<900||x>2250||y<520;
      const key=coastal?'env_palm':'env_tree';
      const scale=(r/30)*.58;
      addWorldProp(key,x,y+23,scale,{sway:true});
      this.rects.push({x,y:y+12,w:20,h:22});
    };
    [[650,320,26],[790,610,30],[930,820,27],[1470,500,30],[1660,750,32],[1850,600,27],[1940,900,32],[2340,1020,29],[2480,1320,32],[1650,1500,30],[1420,1600,26],[880,1350,30],[1020,1580,28],[520,760,26],[720,900,24],[2500,720,30],[2750,960,30],[2600,1600,30]].forEach(a=>tree(...a));
    // Densidade de vegetação por assets; a faixa das estradas e as arenas ficam livres.
    const nearRoad=(x,y)=>(this.roadLines||[]).some(r=>{for(let i=0;i<r.pts.length-1;i++){const [x1,y1]=r.pts[i],[x2,y2]=r.pts[i+1],dx=x2-x1,dy=y2-y1,l2=dx*dx+dy*dy||1;let t=((x-x1)*dx+(y-y1)*dy)/l2;t=Math.max(0,Math.min(1,t));if(Math.hypot(x-(x1+dx*t),y-(y1+dy*t))<r.w/2+34)return true;}return false;});
    for(let i=0,tries=0;tries<1800&&i<175;tries++){
      const x=760+Math.random()*1900,y=260+Math.random()*1680;
      if(Phaser.Math.Distance.Between(x,y,1300,750)<220||Phaser.Math.Distance.Between(x,y,2130,1250)<220)continue;
      if(x>1950&&x<2430&&y>1090&&y<1470)continue;
      if(nearRoad(x,y)||this.rects.some(r=>Math.abs(x-r.x)<r.w/2+38&&Math.abs(y-r.y)<r.h/2+38))continue;
      const roll=Math.random();let key,scale;
      if(roll<.34){key='env_bush';scale=.48+Math.random()*.22;}
      else if(roll<.58){key='env_fern';scale=.46+Math.random()*.22;}
      else if(roll<.82){key='env_rock';scale=.42+Math.random()*.20;}
      else{key='env_bush';scale=.30+Math.random()*.13;}
      addWorldProp(key,x,y,scale,{sway:key==='env_bush'||key==='env_fern'});i++;
    }
    // Props detalhados nas áreas de tráfego e no porto.
    [[92,289,'env_barrel',.48],[126,292,'env_crate',.44],[264,288,'env_crate',.43],[304,316,'env_barrel',.46],[602,580,'env_crate',.5],[650,590,'env_barrel',.45],[1160,610,'env_crate',.45],[1870,1090,'env_barrel',.44],[1910,1100,'env_crate',.46],[350,605,'env_bush',.58],[447,597,'env_fern',.52],[825,405,'env_barrel',.43],[1112,530,'env_crate',.45]].forEach(([x,y,k,sc])=>addWorldProp(k,x,y,sc));
    // Acampamento: paliçada, tendas, fogueira e barris.
    g.lineStyle(7,0x67482f);g.strokeRect(1980,1120,420,310);g.lineStyle(3,0xb08a54);g.strokeRect(1980,1120,420,310);
    for(let x=1990;x<2400;x+=26){g.fillStyle(0x89603b);g.fillTriangle(x,1120,x+12,1098,x+24,1120);g.fillTriangle(x,1430,x+12,1452,x+24,1430);}
    // Tendas, fogueira, barris e caixas recebem assets SVG no bloco seguinte.
    addWorldProp('env_tent',2080,1278,.69);addWorldProp('env_tent',2250,1352,.58);
    this.campfireProp=addWorldProp('env_bonfire',2165,1382,.72);
    [[2010,1310],[2350,1240],[2335,1370],[2160,1180],[2228,1266]].forEach(([x,y],i)=>addWorldProp(i%2?'env_crate':'env_barrel',x,y,.42+Math.random()*.06));
    this.rects.push({x:2080,y:1252,w:70,h:24},{x:2250,y:1325,w:62,h:20});
    // Mastros das bandeiras (o tecido é animado em updateFx): porto de Foosha e acampamento dos bandidos.
    for(const [px,py,ph] of [[288,166,76],[1996,1036,92]]){g.fillStyle(0x4a3322);g.fillRect(px,py,5,ph);g.fillStyle(0xd7ad66);g.fillCircle(px+2.5,py-1,4);g.fillStyle(0x253528,0.3);g.fillEllipse(px+2,py+ph,16,6);}
    this.flagDefs.push({x:293,y:172,w:44,h:26,c1:0x2f7fb0,c2:0x3b8fc2});
    this.flagDefs.push({x:2001,y:1042,w:48,h:30,c1:0xa8312a,c2:0xb93d33,emblem:true});
  }
  // Navegação em grade com A*: evita casas, árvores e construções em vez de andar em linha reta contra a colisão.
  buildNavigationGrid(){
    this.navCell=40;this.navCols=Math.ceil(WW/this.navCell);this.navRows=Math.ceil(WH/this.navCell);this.navBlocked=new Uint8Array(this.navCols*this.navRows);
    for(const r of this.rects){const minX=Math.max(0,Math.floor((r.x-r.w/2-20)/this.navCell)),maxX=Math.min(this.navCols-1,Math.floor((r.x+r.w/2+20)/this.navCell));const minY=Math.max(0,Math.floor((r.y-r.h/2-20)/this.navCell)),maxY=Math.min(this.navRows-1,Math.floor((r.y+r.h/2+20)/this.navCell));for(let y=minY;y<=maxY;y++)for(let x=minX;x<=maxX;x++)this.navBlocked[y*this.navCols+x]=1;}
  }
  gridIndex(x,y){return y*this.navCols+x;}
  gridPoint(x,y){return {x:Math.min(WW-20,x*this.navCell+this.navCell/2),y:Math.min(WH-20,y*this.navCell+this.navCell/2)};}
  isWalkable(x,y,margin=0){if(x<20||y<20||x>WW-20||y>WH-20)return false;return !this.rects.some(r=>Math.abs(x-r.x)<r.w/2+margin&&Math.abs(y-r.y)<r.h/2+margin);}
  nearestOpenCell(cx,cy){cx=Phaser.Math.Clamp(cx,0,this.navCols-1);cy=Phaser.Math.Clamp(cy,0,this.navRows-1);if(!this.navBlocked[this.gridIndex(cx,cy)])return {x:cx,y:cy};for(let rad=1;rad<12;rad++)for(let y=cy-rad;y<=cy+rad;y++)for(let x=cx-rad;x<=cx+rad;x++){if(x<0||y<0||x>=this.navCols||y>=this.navRows)continue;if(Math.abs(x-cx)!==rad&&Math.abs(y-cy)!==rad)continue;if(!this.navBlocked[this.gridIndex(x,y)])return {x,y};}return {x:cx,y:cy};}
  findPath(sx,sy,tx,ty){
    const start=this.nearestOpenCell(Math.floor(sx/this.navCell),Math.floor(sy/this.navCell)),goal=this.nearestOpenCell(Math.floor(tx/this.navCell),Math.floor(ty/this.navCell));
    const startI=this.gridIndex(start.x,start.y),goalI=this.gridIndex(goal.x,goal.y);if(startI===goalI)return [this.gridPoint(goal.x,goal.y)];
    const open=[startI],came=new Int32Array(this.navCols*this.navRows);came.fill(-1);const gScore=new Float32Array(this.navCols*this.navRows);gScore.fill(Infinity);gScore[startI]=0;const fScore=new Float32Array(this.navCols*this.navRows);fScore.fill(Infinity);fScore[startI]=Math.abs(start.x-goal.x)+Math.abs(start.y-goal.y);const inOpen=new Uint8Array(this.navCols*this.navRows);inOpen[startI]=1;let found=false,iterations=0;
    while(open.length&&iterations++<6500){let bi=0;for(let i=1;i<open.length;i++)if(fScore[open[i]]<fScore[open[bi]])bi=i;const cur=open.splice(bi,1)[0];inOpen[cur]=0;if(cur===goalI){found=true;break;}const x=cur%this.navCols,y=Math.floor(cur/this.navCols);for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=this.navCols||ny>=this.navRows)continue;const ni=this.gridIndex(nx,ny);if(this.navBlocked[ni]&&ni!==goalI)continue;const tentative=gScore[cur]+1;if(tentative<gScore[ni]){came[ni]=cur;gScore[ni]=tentative;fScore[ni]=tentative+Math.abs(nx-goal.x)+Math.abs(ny-goal.y);if(!inOpen[ni]){open.push(ni);inOpen[ni]=1;}}}}
    if(!found)return [];const path=[];let cur=goalI;while(cur!==startI&&cur>=0){path.push(this.gridPoint(cur%this.navCols,Math.floor(cur/this.navCols)));cur=came[cur];}path.reverse();return path;
  }
  setMoveTarget(x,y){if(!this.isWalkable(x,y,12)){const c=this.nearestOpenCell(Math.floor(x/this.navCell),Math.floor(y/this.navCell));const p=this.gridPoint(c.x,c.y);x=p.x;y=p.y;}this.moveTarget=new Phaser.Math.Vector2(x,y);this.navPath=this.findPath(this.player.x,this.player.y,x,y);this.navPathIndex=0;this.navGoal={x,y};}
  followNavigation(targetX,targetY){if(!this.navGoal||Math.hypot(this.navGoal.x-targetX,this.navGoal.y-targetY)>55||!this.navPath||this.navPathIndex>=this.navPath.length){this.navPath=this.findPath(this.player.x,this.player.y,targetX,targetY);this.navPathIndex=0;this.navGoal={x:targetX,y:targetY};}while(this.navPath&&this.navPathIndex<this.navPath.length&&Phaser.Math.Distance.Between(this.player.x,this.player.y,this.navPath[this.navPathIndex].x,this.navPath[this.navPathIndex].y)<15)this.navPathIndex++;const p=this.navPath?.[this.navPathIndex]||{x:targetX,y:targetY};const dx=p.x-this.player.x,dy=p.y-this.player.y,l=Math.hypot(dx,dy);if(l<13)return {x:0,y:0};return {x:dx/l,y:dy/l};}
  randomPoint(r){return {x:Phaser.Math.Between(r.x1,r.x2),y:Phaser.Math.Between(r.y1,r.y2)};}
  spawnInRegion(r,forceBoss=false){
    const boss=forceBoss||(r.boss&& !r.bossAlive && Math.random()<0.13);
    if(boss&&r.bossAlive)return null;
    let p=this.randomPoint(r);for(let tries=0;tries<35&&!this.isWalkable(p.x,p.y,20);tries++)p=this.randomPoint(r);if(!this.isWalkable(p.x,p.y,20)){p={x:(r.x1+r.x2)/2,y:(r.y1+r.y2)/2};}
    const e=this.spawnEnemy(p.x,p.y,boss);e.region=r.index;e.level=r.level+(boss?2:0);
    if(boss)r.bossAlive=true;
    return e;
  }
  spawnEnemy(x,y,boss=false){const skin=boss?'boss':'bandit';const e=this.enemies.create(x,y,skin+'_i0').setDepth(worldDepth(y)).setCollideWorldBounds(true).setScale(boss ? 0.78 : 0.62).setSize(boss?44:40,boss?38:34).setOffset(boss?26:28,boss?52:54);e.targetId=this.nextEnemyId++;e.hp=boss?150:32+Math.floor(Math.random()*10);e.maxHp=e.hp;e.atk=boss?12:5;e.xp=boss?110:18;e.boss=boss;e.speed=boss?48:58;e.lastHit=0;e.nextAttackAt=0;e.attacking=false;e.skin=skin;e.play(skin+'_idle');e.anims.setProgress(Math.random());e.shadow=this.add.image(x,y+22,'shadow').setDepth(shadowDepth(y+22)).setAlpha(.42).setScale(boss?1.9:1.38);if(boss){e.label=this.add.text(x,y-64,BOSS_NAME,{fontFamily:'Trebuchet MS, sans-serif',fontSize:'13px',fontStyle:'bold',color:'#ffe9a8',stroke:'#3b1d12',strokeThickness:4}).setOrigin(.5).setDepth(56);}this.spawnFx(e);return e;}
  rollEquipment(e){
    // First roll: chance for any equipment; rarity roll only happens after a successful drop.
    if(Math.random()>=0.15)return null;
    const rarityRoll=Math.random();
    let rarity='Comum',mult=1;
    if(rarityRoll<0.0001){rarity='Mítico';mult=3.2;}
    else if(rarityRoll<0.005){rarity='Lendário';mult=2.6;}
    else if(rarityRoll<0.03){rarity='Épico';mult=2.0;}
    else if(rarityRoll<0.10){rarity='Raro';mult=1.55;}
    else if(rarityRoll<0.30){rarity='Incomum';mult=1.2;}
    const types=[
      {name:'Espada simples',stat:'Ataque',base:2},
      {name:'Armadura de couro',stat:'Defesa',base:2},
      {name:'Botas de viajante',stat:'Vida',base:8},
      {name:'Capacete de couro',stat:'Crítico',base:1}
    ];
    const type=types[Math.floor(Math.random()*types.length)];
    const value=Math.max(1,Math.round((type.base+Math.random()*type.base)*mult*(1+(e.level-1)*0.12)));
    return {id:Date.now()+Math.random(),name:type.name,slot:({'Espada simples':'weapon','Armadura de couro':'armor','Botas de viajante':'boots','Capacete de couro':'helmet'})[type.name],rarity,stat:type.stat,value,level:e.level};
  }
  rarityColor(r){return ({'Comum':'#ded8c8','Incomum':'#7fe0a0','Raro':'#79b9ff','Épico':'#d49bff','Lendário':'#ffca66','Mítico':'#ff7f9f'})[r]||'#fff';}
  addEquipment(item){if(this.shouldAutoSell(item)){const gold=this.itemSellValue(item);this.gold=(this.gold||0)+gold;this.saveProgress();this.renderCharacter();this.toast(`Venda automática: ${item.name} · +${gold} moedas`);return;}this.inventory.unshift(item);this.renderInventory();this.saveProgress();this.toast(`Drop ${item.rarity}: ${item.name} · ${item.stat} +${item.value}`);}
  loadProgress(){try{const d=JSON.parse(localStorage.getItem('dawnProgressV3')||'null');if(!d)return;this.inventory=Array.isArray(d.inventory)?d.inventory:[];this.equipped=d.equipped||{};this.player.level=d.level||1;this.player.xp=d.xp||0;this.player.nextXp=d.nextXp||100;this.kills=d.kills||0;this.gold=d.gold||0;this.huntArea=d.huntArea||null;this.route=Array.isArray(d.route)?d.route:this.route;this.autoSell=d.autoSell||this.autoSell;if(!Array.isArray(this.autoSell.rarities))this.autoSell.rarities=['Comum'];this.passiveSkills=d.passiveSkills||{};}catch(e){console.warn('Save inválido',e);}}
  saveProgress(){try{localStorage.setItem('dawnProgressV3',JSON.stringify({inventory:this.inventory,equipped:this.equipped,level:this.player.level,xp:this.player.xp,nextXp:this.player.nextXp,kills:this.kills||0,gold:this.gold||0,huntArea:this.huntArea,route:this.route,autoSell:this.autoSell,passiveSkills:this.passiveSkills}));}catch(e){console.warn('Falha ao salvar',e);}}
  applyEquipment(){const baseAtk=12+(this.player.level-1)*2,baseHp=100+(this.player.level-1)*10;let atk=baseAtk,hp=baseHp,def=0,crit=0;Object.values(this.equipped).forEach(i=>{if(!i)return;const v=Number(i.value)||0;if(i.stat==='Ataque')atk+=v;if(i.stat==='Vida')hp+=v;if(i.stat==='Defesa')def+=v;if(i.stat==='Crítico')crit+=v;});this.player.atk=atk;this.player.defense=def;this.player.crit=Math.min(75,crit);const old=this.player.maxHp||hp;this.player.maxHp=hp;this.player.hp=Math.min(hp,Math.max(1,(this.player.hp||hp)+hp-old));if(this.hud)this.renderEquipment();}
  itemLabel(i){return `${i.name} · ${i.stat} +${i.value} · ${i.rarity}`;}
  slotFor(item){return item.slot||({'Espada simples':'weapon','Armadura de couro':'armor','Botas de viajante':'boots','Capacete de couro':'helmet'})[item.name]||null;}
  equipItem(id){
    const index=this.inventory.findIndex(i=>String(i.id)===String(id));
    if(index<0){this.toast('Esse item não está mais na mochila');return;}
    const item=this.inventory[index],slot=this.slotFor(item);
    if(!slot){this.toast('Esse item não pode ser equipado');return;}
    const previous=this.equipped[slot];
    this.inventory.splice(index,1);
    if(previous)this.inventory.unshift(previous);
    this.equipped[slot]={...item,slot};this.selectedItem=null;
    this.applyEquipment();this.renderInventory();this.renderEquipment();this.saveProgress();
    this.renderCharacter();this.toast(`${item.name} equipado`);
  }
  unequip(slot){const item=this.equipped[slot];if(!item)return;this.inventory.unshift(item);delete this.equipped[slot];this.applyEquipment();this.renderInventory();this.renderEquipment();this.saveProgress();this.renderCharacter();this.toast(`${item.name} voltou para a mochila`);}
  itemSellValue(item){const base={Comum:8,Incomum:20,Raro:65,Épico:180,Lendário:600,Mítico:2500}[item.rarity]||5;return Math.max(1,Math.round(base+(Number(item.value)||0)*2+(Number(item.level)||1)*3));}
  sellItem(id){const index=this.inventory.findIndex(i=>String(i.id)===String(id));if(index<0)return;const item=this.inventory[index];this.inventory.splice(index,1);const gold=this.itemSellValue(item);this.gold=(this.gold||0)+gold;this.selectedItem=null;this.renderInventory();this.saveProgress();this.renderCharacter();this.toast(`${item.name} vendido por ${gold} moedas`);}
  shouldAutoSell(item){return !!this.autoSell?.enabled&&this.autoSell.rarities.includes(item.rarity);}
  renderAutoSell(){const box=this.hud?.querySelector('#autoselloptions');if(!box)return;const rarities=['Comum','Incomum','Raro','Épico','Lendário','Mítico'];box.innerHTML=rarities.map(r=>`<label class="sellrarity"><input type="checkbox" data-sellrarity="${r}" ${this.autoSell.rarities.includes(r)?'checked':''}><span class="raritydot" style="background:${this.rarityColor(r)}"></span>${r}</label>`).join('');box.querySelectorAll('[data-sellrarity]').forEach(c=>c.onchange=()=>{const r=c.dataset.sellrarity;if(c.checked&&!this.autoSell.rarities.includes(r))this.autoSell.rarities.push(r);else this.autoSell.rarities=this.autoSell.rarities.filter(x=>x!==r);this.saveProgress();});const enabled=this.hud.querySelector('#autosellenabled');enabled.checked=!!this.autoSell.enabled;enabled.onchange=()=>{this.autoSell.enabled=enabled.checked;this.saveProgress();this.toast(enabled.checked?'Venda automática ativada':'Venda automática desativada');};}
  renderCharacter(){if(!this.hud)return;const levelLabel=this.hud.querySelector('#characterlevel');if(levelLabel)levelLabel.textContent=`Nível ${this.player.level} · Ilha Dawn`;const el=this.hud.querySelector('#charstats');if(!el)return;const baseAtk=12+(this.player.level-1)*2,baseHp=100+(this.player.level-1)*10;let gearAtk=0,gearHp=0,gearDef=0,gearCrit=0;Object.values(this.equipped).forEach(i=>{if(!i)return;if(i.stat==='Ataque')gearAtk+=Number(i.value)||0;if(i.stat==='Vida')gearHp+=Number(i.value)||0;if(i.stat==='Defesa')gearDef+=Number(i.value)||0;if(i.stat==='Crítico')gearCrit+=Number(i.value)||0;});const stat=(name,total,bonus,suffix='')=>`<div><small>${name}</small><b>${total}${suffix}</b><em>${bonus?`Base +${bonus}`:'Base'}</em></div>`;el.innerHTML=`<div class="statgrid">${stat('Nível',this.player.level,0)}${stat('Vida',this.player.maxHp,gearHp)}${stat('Ataque',this.player.atk,gearAtk)}${stat('Defesa',this.player.defense||0,gearDef)}${stat('Crítico',this.player.crit||0,gearCrit,'%')}<div><small>Moedas</small><b>${this.gold||0}</b><em>Saldo</em></div><div><small>XP</small><b>${this.player.xp}/${this.player.nextXp}</b><em>Progresso</em></div><div><small>Derrotados</small><b>${this.kills||0}</b><em>Total</em></div></div><p class="basehint">A ficha mostra o valor atual e o bônus de equipamento separado. Velocidade e habilidades passivas serão adicionadas quando seus sistemas estiverem ativos.</p>`;}
  renderTalentTree(){const el=this.hud?.querySelector('#talenttree');if(!el)return;const nodes=[['fundamentos','Fundamentos do Pirata','+5% de vida máxima'],['combate','Técnica de Combate','+3% de ataque'],['saque','Olho de Saqueador','+2% de chance de drop'],['velocidade','Passos Leves','+3% de velocidade']];el.innerHTML=nodes.map((n,i)=>`<div class="talentnode ${this.passiveSkills[n[0]]?'unlocked':''}"><span>${['♥','⚔','◆','➤'][i]}</span><b>${n[1]}</b><small>${n[2]}</small><button data-talent="${n[0]}" ${this.passiveSkills[n[0]]?'disabled':''}>${this.passiveSkills[n[0]]?'Desbloqueada':'Em breve'}</button></div>`).join('')+'<p class="basehint">Árvore visual em preparação. Os nós aparecem como prévia; pontos de habilidade e efeitos reais serão implementados junto ao sistema de níveis.</p>';}

  renderEquipment(){if(!this.hud)return;const el=this.hud.querySelector('#equipped');if(!el)return;const labels={weapon:'⚔ Arma',helmet:'◉ Capacete',armor:'▣ Armadura',boots:'◈ Botas'};el.innerHTML=Object.entries(labels).map(([slot,label])=>{const item=this.equipped[slot];return `<div class="equipline"><span>${label}</span><span class="equipname" style="color:${this.rarityColor(item?.rarity)}">${item?this.escapeHtml(item.name)+' +'+item.value:'<i>Vazio</i>'}</span>${item?`<button data-unequip="${slot}">Retirar</button>`:''}</div>`;}).join('');el.querySelectorAll('[data-unequip]').forEach(b=>b.onclick=()=>this.unequip(b.dataset.unequip));this.hud.querySelector('#combatstats').textContent=`ATQ ${this.player.atk} · DEF ${this.player.defense||0} · CRIT ${this.player.crit||0}%`;}
  escapeHtml(t){return String(t??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  itemIcon(i){return ({weapon:'⚔️',armor:'🛡️',boots:'🥾',helmet:'🪖'})[this.slotFor(i)]||'📦';}
  renderInventory(){if(!this.hud)return;const box=this.hud.querySelector('#items');this.hud.querySelector('#itemcount').textContent=this.inventory.length;const sort=this.hud.querySelector('#bagsort')?.value||'new';const rarityOrder={'Mítico':6,'Lendário':5,'Épico':4,'Raro':3,'Incomum':2,'Comum':1};const items=[...this.inventory];if(sort==='rarity')items.sort((a,b)=>(rarityOrder[b.rarity]||0)-(rarityOrder[a.rarity]||0));else if(sort==='name')items.sort((a,b)=>a.name.localeCompare(b.name));else items.sort((a,b)=>(b.id||0)-(a.id||0));if(!items.length){box.innerHTML='<div class="emptybag"><span>🎒</span><b>A mochila está vazia</b><small>Derrote inimigos para encontrar equipamentos.</small></div>';return;}box.innerHTML=items.map(i=>{const slot=i.slot||({'Espada simples':'weapon','Armadura de couro':'armor','Botas de viajante':'boots','Capacete de couro':'helmet'})[i.name];const old=this.equipped[slot];const delta=old&&old.stat===i.stat?i.value-old.value:null;return `<button class="bagitem ${String(this.selectedItem)===String(i.id)?'selected':''}" data-select="${i.id}" style="--rarity:${this.rarityColor(i.rarity)}"><span class="itemicon">${this.itemIcon(i)}</span><span class="itemname">${this.escapeHtml(i.name)}<small>${this.escapeHtml(i.rarity)} · Nv. ${i.level||1}</small></span><span class="itemstat">${this.escapeHtml(i.stat)} +${i.value}${delta!==null?`<small class="${delta>=0?'better':'worse'}">${delta>=0?'+':''}${delta} vs atual</small>`:''}</span></button>`;}).join('');box.querySelectorAll('[data-select]').forEach(b=>b.onclick=()=>{this.selectedItem=b.dataset.select;this.renderInventory();this.renderItemDetail(b.dataset.select);});if(this.selectedItem&&!items.some(i=>String(i.id)===String(this.selectedItem)))this.selectedItem=null;if(this.selectedItem)this.renderItemDetail(this.selectedItem);else this.hud.querySelector('#itemdetail').innerHTML='Selecione um item para ver detalhes e comparar atributos.';}
  renderItemDetail(id){const item=this.inventory.find(i=>String(i.id)===String(id));const box=this.hud?.querySelector('#itemdetail');if(!box||!item)return;const slot=item.slot||({'Espada simples':'weapon','Armadura de couro':'armor','Botas de viajante':'boots','Capacete de couro':'helmet'})[item.name];const current=this.equipped[slot];const delta=current&&current.stat===item.stat?item.value-current.value:null;box.innerHTML=`<div class="detailhead"><span class="detailicon">${this.itemIcon(item)}</span><div><b style="color:${this.rarityColor(item.rarity)}">${this.escapeHtml(item.name)}</b><small>${this.escapeHtml(item.rarity)} · Equipamento de ${({weapon:'arma',armor:'armadura',boots:'botas',helmet:'cabeça'})[slot]||'aventura'}</small></div></div><div class="detailstat"><span>${this.escapeHtml(item.stat)}</span><b>+${item.value}</b></div>${current?`<div class="compare"><small>Atual: ${this.escapeHtml(current.name)} (+${current.value} ${this.escapeHtml(current.stat)})</small><b class="${delta===null?'':delta>=0?'better':'worse'}">${delta===null?'Atributos diferentes':`${delta>=0?'+':''}${delta} ${item.stat}`}</b></div>`:'<small>Este espaço está vazio.</small>'}<div class="itemdetailactions"><button class="equipaction" id="equipselected">Equipar item</button><button class="sellaction" id="sellselected">Vender · ${this.itemSellValue(item)} moedas</button></div>`;box.querySelector('#equipselected').onclick=()=>this.equipItem(id);box.querySelector('#sellselected').onclick=()=>this.sellItem(id);}
  mapCoords(ev){const c=this.hud.querySelector('#islandmap'),r=c.getBoundingClientRect();return {x:Math.round(Phaser.Math.Clamp((ev.clientX-r.left)/r.width*WW,0,WW)),y:Math.round(Phaser.Math.Clamp((ev.clientY-r.top)/r.height*WH,0,WH))};}
  renderMap(preview=null){if(!this.hud)return;const c=this.hud.querySelector('#islandmap');if(!c)return;const ctx=c.getContext('2d');const w=c.width,h=c.height;ctx.clearRect(0,0,w,h);ctx.fillStyle='#669453';ctx.fillRect(0,0,w,h);ctx.fillStyle='#46a4b9';ctx.fillRect(0,0,w,160/WH*h);ctx.fillStyle='#e0c78b';ctx.fillRect(0,145/WH*h,w,90/WH*h);ctx.strokeStyle='#bba374';ctx.lineWidth=13;ctx.beginPath();[[100,500],[560,500],[780,700],[1180,720],[1450,940],[1840,1000],[2200,1250]].forEach(([x,y],i)=>i?ctx.lineTo(x/WW*w,y/WH*h):ctx.moveTo(x/WW*w,y/WH*h));ctx.stroke();this.regions.forEach(r=>{ctx.strokeStyle='#ffffff55';ctx.strokeRect(r.x1/WW*w,r.y1/WH*h,(r.x2-r.x1)/WW*w,(r.y2-r.y1)/WH*h);ctx.fillStyle='#f8e8bf';ctx.font='11px sans-serif';ctx.fillText(r.name,r.x1/WW*w,r.y1/WH*h-4);});if(this.huntArea){const a=this.huntArea;ctx.fillStyle='#f7d35b38';ctx.strokeStyle='#f7d35b';ctx.lineWidth=2;ctx.fillRect(a.x/WW*w,a.y/WH*h,a.w/WW*w,a.h/WH*h);ctx.strokeRect(a.x/WW*w,a.y/WH*h,a.w/WW*w,a.h/WH*h);}if(preview&&preview.start&&this.mapMode==='area'){const a=preview.start,b=preview.preview;ctx.fillStyle='#f7d35b38';ctx.strokeStyle='#f7d35b';ctx.fillRect(Math.min(a.x,b.x)/WW*w,Math.min(a.y,b.y)/WH*h,Math.abs(a.x-b.x)/WW*w,Math.abs(a.y-b.y)/WH*h);ctx.strokeRect(Math.min(a.x,b.x)/WW*w,Math.min(a.y,b.y)/WH*h,Math.abs(a.x-b.x)/WW*w,Math.abs(a.y-b.y)/WH*h);}if(this.route.length){ctx.strokeStyle='#ffdb64';ctx.lineWidth=2;ctx.beginPath();this.route.forEach((p,i)=>i?ctx.lineTo(p.x/WW*w,p.y/WH*h):ctx.moveTo(p.x/WW*w,p.y/WH*h));ctx.stroke();}this.enemies?.getChildren().forEach(e=>{if(!e.active)return;ctx.fillStyle=e.boss?'#ff8c42':'#e8e0c8';ctx.beginPath();ctx.arc(e.x/WW*w,e.y/WH*h,e.boss?4:2.5,0,Math.PI*2);ctx.fill();});if(this.player){ctx.fillStyle='#ff4444';ctx.beginPath();ctx.arc(this.player.x/WW*w,this.player.y/WH*h,5,0,Math.PI*2);ctx.fill();}const mini=this.hud.querySelector('#minimap');if(mini){const mctx=mini.getContext('2d');mctx.clearRect(0,0,mini.width,mini.height);mctx.drawImage(c,0,0,mini.width,mini.height);const px=this.player.x/WW*mini.width,py=this.player.y/WH*mini.height;mctx.strokeStyle='#ffffff';mctx.lineWidth=2;mctx.beginPath();mctx.arc(px,py,5,0,Math.PI*2);mctx.stroke();}}
  setupMapEditor(){const c=this.hud.querySelector('#islandmap');let start=null,moved=false;c.onpointerdown=e=>{start=this.mapCoords(e);moved=false;c.setPointerCapture(e.pointerId);};c.onpointermove=e=>{if(!start)return;const p=this.mapCoords(e);if(Math.abs(p.x-start.x)>5||Math.abs(p.y-start.y)>5)moved=true;this.renderMap({preview:p,start});};c.onpointerup=e=>{if(!start)return;const end=this.mapCoords(e);if(this.mapMode==='route'){if(!moved){this.route.push(end);this.routeIndex=Math.max(0,this.route.length-1);this.drawRoute();this.toast(`Ponto ${this.route.length} adicionado à rota`);}}else if(moved){const x=Math.min(start.x,end.x),y=Math.min(start.y,end.y);this.huntArea={x,y,w:Math.max(180,Math.abs(end.x-start.x)),h:Math.max(180,Math.abs(end.y-start.y))};this.toast('Área de caça definida');}else{this.huntArea={x:Math.max(0,end.x-220),y:Math.max(0,end.y-220),w:440,h:440};this.toast('Área de caça marcada');}start=null;this.renderMap();this.updateRouteInfo();this.saveProgress();};c.onpointercancel=()=>{start=null;this.renderMap();};this.hud.querySelector('#mapmode').onchange=e=>{this.mapMode=e.target.value;this.hud.querySelector('#maphelp').textContent=this.mapMode==='area'?'Arraste para delimitar uma área; um toque marca uma área ao redor do ponto.':'Toque em vários pontos para desenhar a rota. Os pontos são ilimitados.';};}
  drawRoute(){if(this.routeGraphics)this.routeGraphics.destroy();this.routeGraphics=this.add.graphics().setDepth(40);if(!this.route.length)return;this.routeGraphics.lineStyle(5,0xffd35c,.9);this.routeGraphics.fillStyle(0xffef9b,1);this.route.forEach((p,i)=>{this.routeGraphics.fillCircle(p.x,p.y,9);this.routeGraphics.fillStyle(0xffffff,1);this.routeGraphics.fillCircle(p.x,p.y,3);this.routeGraphics.fillStyle(0xffef9b,1);if(i>0)this.routeGraphics.lineBetween(this.route[i-1].x,this.route[i-1].y,p.x,p.y);});if(this.route.length>1)this.routeGraphics.lineBetween(this.route[this.route.length-1].x,this.route[this.route.length-1].y,this.route[0].x,this.route[0].y);}
  updateRouteInfo(){this.hud.querySelector('#routeinfo').textContent=this.route.length?`${this.route.length} pontos · ciclo ativo quando a caça estiver ligada`:'0 pontos · rota não definida';}
  routePoint(){if(!this.route.length)return null;let p=this.route[this.routeIndex%this.route.length];if(Phaser.Math.Distance.Between(this.player.x,this.player.y,p.x,p.y)<36){this.routeIndex=(this.routeIndex+1)%this.route.length;p=this.route[this.routeIndex%this.route.length];}return p;}
  makeHUD(){
    this.hud=document.createElement('div');this.hud.id='hud';this.hud.innerHTML=`<header><div class="brand"><b>☠ DAWN ISLAND</b><small>ONE PIECE IDLE RPG · VISUAL 2.5D v1.1</small></div><div class="stats"><span id="lvl">LV 1</span><span class="meter-pill"><b id="hp">HP 100/100</b><i class="meter-track"><u id="hpfill"></u></i></span><span class="meter-pill"><b id="xp">XP 0/100</b><i class="meter-track xp-track"><u id="xpfill"></u></i></span><span id="kills">KOs 0</span></div><div class="head-actions"><button id="auto">⚔ Caça OFF</button><button id="openmap">🗺 Mapa</button><button id="openinv">🎒 Mochila <span id="itemcount">0</span></button><button id="openchar">👤 Personagem</button><button id="opensettings">⚙ Caça</button></div></header><div class="zone"><b id="zone">Vila Foosha</b><small id="zoneinfo">Mobs ativos: 0</small></div><section id="battlepanel"><div class="battle-title"><b>⚔ BATALHA</b><small>ALVOS PRÓXIMOS</small></div><div id="targetsummary">Clique em um inimigo para selecionar</div><div id="battlelist"></div></section><div class="minimapbox"><canvas id="minimap" width="220" height="160"></canvas><small>MINIMAPA · toque para ampliar</small></div><div id="toast"></div><div id="mapmodal" hidden><div class="mapwindow"><div class="maptop"><div><b>🗺 MAPA DA ILHA DAWN</b><small>Selecione uma área ou desenhe uma rota</small></div><button id="closemap">✕</button></div><div class="maptools"><label>Modo <select id="mapmode"><option value="area">Área de caça</option><option value="route">Rota personalizada</option></select></label><button id="saveroute">Salvar rota</button><button id="clearroute">Limpar rota</button><button id="clearmap">Limpar caça</button></div><p id="maphelp">Arraste no mapa para marcar uma área de caça.</p><canvas id="islandmap" width="900" height="660"></canvas><div class="maplegend"><span>🔴 Você</span><span>🟡 Área/rota</span><span>🔸 Inimigos</span></div><small id="routeinfo">Nenhuma rota definida</small></div></div><div id="backpackmodal" hidden><div class="backpackwindow"><div class="backpacktop"><div><b>🎒 MOCHILA</b><small id="bagcaption">Itens coletados durante a aventura</small></div><button id="closeinv">✕</button></div><div class="baglayout"><section class="gearcolumn"><h3>Equipamento</h3><div id="equipped"></div><div id="combatstats"></div><div class="charpreview"><div class="previewhero"><img src="assets/characters/hero_f_i0.svg" alt="Pirata protagonista"></div><b>AVENTUREIRO</b><small>Equipamentos ativos</small></div></section><section class="bagcolumn"><div class="bagtoolbar"><b>Itens guardados</b><select id="bagsort"><option value="new">Mais recentes</option><option value="rarity">Raridade</option><option value="name">Nome</option></select></div><div id="items" class="itemgrid"></div><div id="itemdetail" class="itemdetail">Selecione um item para ver detalhes e comparar atributos.</div></section></div></div></div><div id="charactermodal" hidden><div class="backpackwindow characterwindow"><div class="backpacktop"><div><b>👤 PERSONAGEM</b><small>Status base, bônus e progressão futura</small></div><button id="closechar">✕</button></div><div class="charprofile"><div class="charportrait"><img src="assets/characters/hero_f_i0.svg" alt="Pirata protagonista"></div><div><h2>Aventureiro</h2><p id="characterlevel">Nível 1 · Ilha Dawn</p><div id="charstats"></div></div></div><div class="talentsection"><h3>Árvore de habilidades passivas</h3><div id="talenttree" class="talenttree"></div></div></div></div><div id="settingsmodal" hidden><div class="backpackwindow settingswindow"><div class="backpacktop"><div><b>⚙ CONFIGURAÇÕES DA CAÇA</b><small>Venda automática de equipamentos</small></div><button id="closesettings">✕</button></div><div class="settingscard"><label class="toggleline"><input type="checkbox" id="autosellenabled"><span><b>Ativar venda automática</b><small>Itens selecionados serão vendidos imediatamente ao cair.</small></span></label><h3>Raridades para vender</h3><div id="autoselloptions" class="autoselloptions"></div><p class="basehint">Sugestão: venda Comum e Incomum; guarde Raro ou superior para revisar. Itens já equipados nunca são vendidos automaticamente.</p></div></div></div><div class="actions"><button id="attack">👊 Soco <kbd>Espaço</kbd></button><button id="skill">💥 Bazuca <kbd>Q</kbd></button><button id="skill2">👊 Gatling <kbd>1</kbd></button></div><div class="stick" id="stick"><div id="knob"></div></div><div class="hint">WASD/Setas mover · Espaço: soco · Q: Bazuca em área · 1: Gatling · E: caça · clique em inimigo: selecionar</div>`;
    document.body.appendChild(this.hud);this.hud.querySelector('#auto').onclick=()=>this.toggleAuto();this.hud.querySelector('#attack').onclick=()=>this.attack();this.hud.querySelector('#skill').onclick=()=>this.skill();this.hud.querySelector('#skill2').onclick=()=>this.gatling();this.hud.querySelector('#battlelist').onclick=e=>{const row=e.target.closest('[data-target-id]');if(!row)return;const id=Number(row.dataset.targetId),target=this.enemies.getChildren().find(enemy=>enemy.active&&enemy.targetId===id);if(target){this.selectTarget(target);const dist=Phaser.Math.Distance.Between(this.player.x,this.player.y,target.x,target.y);if(dist>78&&!this.auto){this.chaseTarget=target;this.setMoveTarget(target.x,target.y);}else if(dist<=78){this.chaseTarget=null;this.moveTarget=null;}}};
    this.hud.querySelector('#openmap').onclick=()=>{this.hud.querySelector('#mapmodal').hidden=false;this.renderMap();};this.hud.querySelector('#minimap').onclick=()=>{this.hud.querySelector('#mapmodal').hidden=false;this.renderMap();};this.hud.querySelector('#closemap').onclick=()=>this.hud.querySelector('#mapmodal').hidden=true;
    this.hud.querySelector('#openinv').onclick=()=>{this.hud.querySelector('#backpackmodal').hidden=false;this.renderInventory();this.renderEquipment();};this.hud.querySelector('#closeinv').onclick=()=>this.hud.querySelector('#backpackmodal').hidden=true;this.hud.querySelector('#openchar').onclick=()=>{this.hud.querySelector('#charactermodal').hidden=false;this.renderCharacter();this.renderTalentTree();};this.hud.querySelector('#closechar').onclick=()=>this.hud.querySelector('#charactermodal').hidden=true;this.hud.querySelector('#opensettings').onclick=()=>{this.hud.querySelector('#settingsmodal').hidden=false;this.renderAutoSell();};this.hud.querySelector('#closesettings').onclick=()=>this.hud.querySelector('#settingsmodal').hidden=true;
    this.hud.querySelector('#saveroute').onclick=()=>{try{localStorage.setItem('dawnFarmRoute',JSON.stringify({name:this.routeName,points:this.route}));this.saveProgress();this.toast('Rota salva neste navegador');}catch(e){this.toast('Não foi possível salvar a rota');}};
    this.hud.querySelector('#clearroute').onclick=()=>{this.route=[];this.routeIndex=0;this.navGoal=null;this.drawRoute();this.updateRouteInfo();this.renderMap();this.saveProgress();};
    this.hud.querySelector('#bagsort').onchange=()=>this.renderInventory();this.setupMapEditor();this.renderAutoSell();this.renderCharacter();this.renderTalentTree();
    this.hud.querySelector('#clearmap').onclick=()=>{this.huntArea=null;this.renderMap();this.saveProgress();this.toast('Área de caça removida');};
    this.joy={active:false,id:null,dx:0,dy:0};const st=this.hud.querySelector('#stick');st.onpointerdown=e=>{this.joy.active=true;this.joy.id=e.pointerId;st.setPointerCapture(e.pointerId);this.joyMove(e);};st.onpointermove=e=>this.joyMove(e);st.onpointerup=()=>this.joyEnd();st.onpointercancel=()=>this.joyEnd();
  }
  joyMove(e){if(!this.joy.active||e.pointerId!==this.joy.id)return;const r=this.hud.querySelector('#stick').getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),m=r.width*.32,l=Math.max(1,Math.hypot(dx,dy));this.joy.dx=Phaser.Math.Clamp(dx/m,-1,1);this.joy.dy=Phaser.Math.Clamp(dy/m,-1,1);this.hud.querySelector('#knob').style.transform=`translate(${this.joy.dx*m}px,${this.joy.dy*m}px)`;this.moveTarget=null;}
  joyEnd(){this.joy.active=false;this.joy.dx=this.joy.dy=0;this.hud.querySelector('#knob').style.transform='translate(0,0)';}
  toggleAuto(){this.auto=!this.auto;this.hud.querySelector('#auto').textContent=this.auto?'⚔ Caça automática: ON':'⚔ Caça automática: OFF';this.hud.querySelector('#auto').classList.toggle('active',this.auto);this.toast(this.auto?'Caça automática ativada':'Caça automática pausada');}
  toast(t){const el=this.hud.querySelector('#toast');el.textContent=t;el.classList.add('show');clearTimeout(this.toastTimer);this.toastTimer=setTimeout(()=>el.classList.remove('show'),1500);}
  nearest(max=220,area=null){let best=null,dist=max;this.enemies.getChildren().forEach(e=>{if(!e.active||e.hp<=0)return;if(area&&(e.x<area.x||e.x>area.x+area.w||e.y<area.y||e.y>area.y+area.h))return;const d=Phaser.Math.Distance.Between(this.player.x,this.player.y,e.x,e.y);if(d<dist){best=e;dist=d;}});return best;}
  findEnemyAt(x,y,radius=34){let best=null,dist=radius;this.enemies?.getChildren().forEach(e=>{if(!e.active||e.hp<=0)return;const d=Phaser.Math.Distance.Between(x,y,e.x,e.y);if(d<dist){dist=d;best=e;}});return best;}
  selectTarget(e,notify=false){const next=e?.active&&e.hp>0?e:null;if(this.selectedEnemy===next)return;this.selectedEnemy=next;if(this.selectedEnemy&&notify)this.toast(`${this.selectedEnemy.boss?BOSS_NAME:'Bandido'} selecionado`);this.renderBattlePanel(true);}
  renderBattlePanel(force=false){if(!this.hud||!this.enemies)return;const now=this.time?.now||0;if(!force&&now-this.lastBattleRender<320)return;this.lastBattleRender=now;const root=this.hud.querySelector('#battlelist');if(!root)return;const nearby=this.enemies.getChildren().filter(e=>e.active&&e.hp>0&&Phaser.Math.Distance.Between(this.player.x,this.player.y,e.x,e.y)<620).sort((a,b)=>Phaser.Math.Distance.Between(this.player.x,this.player.y,a.x,a.y)-Phaser.Math.Distance.Between(this.player.x,this.player.y,b.x,b.y)).slice(0,6);root.innerHTML=nearby.length?nearby.map(e=>{const ratio=Math.max(0,Math.min(1,e.hp/e.maxHp));const picked=this.selectedEnemy===e;return `<button class="battle-row ${picked?'selected':''} ${e.boss?'boss-row':''}" data-target-id="${e.targetId}"><span class="battle-icon">${e.boss?'♛':'⚔'}</span><span class="battle-meta"><b>${e.boss?BOSS_NAME:'Bandido'} <small>Lv.${e.level||1}</small></b><i><span style="width:${ratio*100}%"></span></i></span><em>${Math.ceil(e.hp)}/${e.maxHp}</em></button>`;}).join(''):'<div class="battle-empty">Nenhum inimigo próximo</div>';const picked=this.selectedEnemy?.active?this.selectedEnemy:null;this.hud.querySelector('#targetsummary').textContent=picked?`Alvo: ${picked.boss?BOSS_NAME:'Bandido'} · ${Math.ceil(picked.hp)}/${picked.maxHp} HP`:'Clique em um inimigo para selecionar';this.updateSkillButtons();}
  attack(){if(this.time.now-this.lastAttack<420)return;let e=this.selectedEnemy;if(!e?.active||e.hp<=0||Phaser.Math.Distance.Between(this.player.x,this.player.y,e.x,e.y)>78)e=this.nearest(78);if(!e){this.toast('Nenhum inimigo ao alcance');return;}this.selectTarget(e);this.lastAttack=this.time.now;this.damage(e,this.player.atk*(Math.random()*100<(this.player.crit||0)?2:1),'basic');}
  skill(){if(this.time.now<this.skillReadyAt){this.toast(`Bazuca recarregando · ${Math.ceil((this.skillReadyAt-this.time.now)/1000)}s`);return;}let e=this.selectedEnemy;if(!e?.active||e.hp<=0||Phaser.Math.Distance.Between(this.player.x,this.player.y,e.x,e.y)>155)e=this.nearest(155);if(!e){this.toast('Nenhum inimigo para atingir');return;}this.skillReadyAt=this.time.now+2600;this.selectTarget(e);this.lastAttack=this.time.now;this.punchFx(e,this.player.atk*2.25,()=>this.applyBazucaDamage(e,this.player.atk*2.25),'bazuca');this.toast('Gomu Gomu no Bazuca!');this.updateSkillButtons();}
  gatling(){if(this.time.now<this.gatlingReadyAt){this.toast(`Metralhadora recarregando · ${Math.ceil((this.gatlingReadyAt-this.time.now)/1000)}s`);return;}let e=this.selectedEnemy;if(!e?.active||e.hp<=0||Phaser.Math.Distance.Between(this.player.x,this.player.y,e.x,e.y)>130)e=this.nearest(130);if(!e){this.toast('Nenhum inimigo para atingir');return;}this.gatlingReadyAt=this.time.now+6200;this.selectTarget(e);this.lastAttack=this.time.now;const p=this.player;p.punchUntil=this.time.now+720;p.play('hero_s_attack',true);this.toast('Gomu Gomu no Gatling!');for(let i=0;i<4;i++)this.time.delayedCall(115+i*135,()=>{if(!e.active||e.hp<=0)return;this.quickStrikeFx(e,i);this.applyDamage(e,this.player.atk*.72);});this.updateSkillButtons();}
  updateSkillButtons(){if(!this.hud)return;const now=this.time?.now||0;if(this._skillHudAt!==undefined&&now-this._skillHudAt<150)return;this._skillHudAt=now;const baz=this.hud.querySelector('#skill'),gat=this.hud.querySelector('#skill2');if(baz){const left=Math.max(0,this.skillReadyAt-this.time.now);baz.innerHTML=left?`💥 Bazuca <kbd>${(left/1000).toFixed(1)}s</kbd>`:'💥 Bazuca <kbd>Q</kbd>';baz.classList.toggle('cooldown',left>0);}if(gat){const left=Math.max(0,this.gatlingReadyAt-this.time.now);gat.innerHTML=left?`👊 Gatling <kbd>${(left/1000).toFixed(1)}s</kbd>`:'👊 Gatling <kbd>1</kbd>';gat.classList.toggle('cooldown',left>0);}}
  damage(e,n,style='basic'){
    if(!e?.active||e.hp<=0)return;
    this.punchFx(e,n,()=>this.applyDamage(e,n),style);
  }
  applyBazucaDamage(primary,n){if(!primary?.active||primary.hp<=0)return;const p=this.player;const base=Math.atan2(primary.y-p.y,primary.x-p.x);let hit=0;const list=this.enemies.getChildren().slice();for(const e of list){if(!e.active||e.hp<=0)continue;const dx=e.x-p.x,dy=e.y-p.y,d=Math.hypot(dx,dy);const angle=Math.atan2(dy,dx);let diff=Math.atan2(Math.sin(angle-base),Math.cos(angle-base));if(d<=175&&Math.abs(diff)<=.92){this.applyDamage(e,e===primary?n:Math.round(n*.62));hit++;}}if(!hit)this.applyDamage(primary,n);this.bazucaWave(primary.x,primary.y,base);}
  quickStrikeFx(e,idx){if(!e?.active)return;const side=(idx%2?1:-1),x=e.x-side*12,y=e.y-5+idx%2*8;const slash=this.add.image(x,y,'fx_slash_blue').setDepth(49).setOrigin(.5,.5).setScale(.42,.52).setRotation((idx%2?-.45:.42)+(side<0?Math.PI:0)).setFlipY(idx%2===1);this.tweens.add({targets:slash,alpha:0,scaleX:.7,scaleY:.7,x:x+side*8,duration:105,onComplete:()=>slash.destroy()});this.impactFx(e.x,e.y,false);}
  bazucaWave(x,y,angle){const wave=this.add.graphics().setDepth(48);const dx=Math.cos(angle),dy=Math.sin(angle);wave.lineStyle(8,0xffbd5d,.78);wave.beginPath();wave.moveTo(x-dx*48-dy*25,y-dy*48+dx*25);wave.lineTo(x+dx*10-dy*43,y+dy*10+dx*43);wave.lineTo(x+dx*78,y+dy*78);wave.lineTo(x+dx*10+dy*43,y+dy*10-dx*43);wave.closePath();wave.strokePath();this.tweens.add({targets:wave,alpha:0,scaleX:1.22,scaleY:1.22,duration:260,ease:'Cubic.easeOut',onComplete:()=>wave.destroy()});}
  applyDamage(e,n){
    if(!e?.active||e.hp<=0)return;
    e.hp-=n;e.setTint(0xff7777);this.time.delayedCall(120,()=>{if(e.active)e.clearTint();});
    const t=this.add.text(e.x,e.y-(e.boss?38:31),`-${Math.round(n)}`,{fontFamily:'Impact, Trebuchet MS, sans-serif',fontSize:n>=this.player.atk*1.9?'20px':'16px',fontStyle:'bold',color:n>=this.player.atk*1.9?'#ffe36e':'#fff2bd',stroke:'#4b1d17',strokeThickness:4}).setOrigin(.5).setDepth(50);
    this.tweens.add({targets:t,y:t.y-25,scale:{from:.8,to:1.1},alpha:0,duration:650,ease:'Cubic.easeOut',onComplete:()=>t.destroy()});
    if(e.hp<=0){const x=e.x,y=e.y,xp=e.xp,wasBoss=e.boss,regionIndex=e.region;if(this.selectedEnemy===e)this.selectTarget(null);this.killFx(e);this.kills=(this.kills||0)+1;if(wasBoss&&this.regions[regionIndex])this.regions[regionIndex].bossAlive=false;this.player.xp+=xp;this.saveProgress();while(this.player.xp>=this.player.nextXp){this.player.xp-=this.player.nextXp;this.player.level++;this.player.nextXp=Math.floor(this.player.nextXp*1.35);this.player.maxHp+=10;this.player.hp=this.player.maxHp;this.applyEquipment();this.levelFx();this.toast(`Nível ${this.player.level}!`);}const d=this.drops.create(x,y,'coin');this.coinFx(d);this.time.delayedCall(8000,()=>{if(d.active)d.destroy();});const item=this.rollEquipment({level:e.level||1});if(item)this.addEquipment(item);else this.toast(`${wasBoss?'Chefe':'Bandido'} derrotado · +${xp} XP`);}
  }
  // ================= v0.7 — ANIMAÇÕES =================
  pick(a){return a[Math.floor(Math.random()*a.length)];}
  drift(o,dir,dur){const a=dir>0?-140:WW+140,b=dir>0?WW+140:-140;const first=Math.max(200,Math.abs(b-o.x)/(WW+280)*dur);this.tweens.add({targets:o,x:b,duration:first,onComplete:()=>{o.x=a;this.tweens.add({targets:o,x:b,duration:dur,repeat:-1});}});}
  burst(x,y,key,n,cfg={},life=900){const em=this.add.particles(x,y,key,Object.assign({lifespan:500,speed:{min:30,max:90},scale:{start:1,end:0},alpha:{start:1,end:0},emitting:false},cfg)).setDepth(cfg.depth||49);em.explode(n);this.time.delayedCall(life,()=>em.destroy());return em;}
  floatText(x,y,t,o={}){const tx=this.add.text(x,y,t,{fontFamily:'Impact, Trebuchet MS, sans-serif',fontSize:(o.size||16)+'px',color:o.color||'#fff2bd',stroke:o.stroke||'#4b1d17',strokeThickness:o.thick||5}).setOrigin(.5).setDepth(60).setAngle((Math.random()-.5)*14);const dur=o.dur||750;this.tweens.add({targets:tx,y:y-(o.rise||30),scale:{from:.6,to:1.15},duration:dur,ease:'Cubic.easeOut'});this.tweens.add({targets:tx,alpha:0,delay:dur*.5,duration:dur*.5,onComplete:()=>tx.destroy()});}

  animateMap(){
    const T=this.tweens;
    // Mar: duas camadas de ondas deslizando em sentidos opostos + espuma que vai e volta com a maré.
    this.waveA=this.add.tileSprite(0,8,WW,140,'wave').setOrigin(0,0).setDepth(-9).setAlpha(.8);
    this.waveB=this.add.tileSprite(0,30,WW,115,'wave').setOrigin(0,0).setDepth(-9).setAlpha(.5).setTileScale(1.6);
    this.foam=this.add.tileSprite(0,142,WW,18,'foam').setOrigin(0,0).setDepth(-9);
    T.add({targets:this.foam,y:{from:138,to:152},alpha:{from:.95,to:.35},duration:2600,yoyo:true,repeat:-1,ease:'Sine.easeInOut'});
    // Ondulações na enseada do porto.
    for(let i=0;i<8;i++){const r=this.add.image(70+Math.random()*190,160+Math.random()*80,'ripple').setDepth(-8).setAlpha(0);T.add({targets:r,scale:{from:.3,to:1.1},alpha:{from:.7,to:0},duration:2400,repeat:-1,delay:Math.random()*2400});}
    // Barco de pesca balançando, com a vela ao vento.
    const hull=this.add.graphics();hull.fillStyle(0x523b2a);hull.fillEllipse(0,0,160,60);hull.fillStyle(0x9a6739);hull.fillEllipse(0,-4,142,45);hull.fillStyle(0x6a4329);hull.fillRect(-4,-42,7,70);
    hull.lineStyle(2,0x7a5232,.9);for(let i=-52;i<=52;i+=26){hull.beginPath();hull.moveTo(i,-16);hull.lineTo(i+8,10);hull.strokePath();}
    const sail=this.add.graphics().setPosition(3,-40);sail.fillStyle(0xf2dfb4);sail.fillTriangle(0,0,45,29,0,50);sail.lineStyle(2,0x583c28);sail.strokeTriangle(0,0,45,29,0,50);sail.lineStyle(1,0xd2bd8b);sail.beginPath();sail.moveTo(0,25);sail.lineTo(36,27);sail.strokePath();
    this.boat=this.add.container(170,205,[hull,sail]).setDepth(-6);
    T.add({targets:this.boat,y:{from:202,to:208},angle:{from:-1.8,to:1.8},duration:2300,yoyo:true,repeat:-1,ease:'Sine.easeInOut'});
    T.add({targets:sail,scaleX:{from:.82,to:1.08},duration:1100,yoyo:true,repeat:-1,ease:'Sine.easeInOut'});
    // Movimento ambiental sutil nos assets de folhagem, sem alterar os pontos de colisão.
    (this.environmentProps||[]).filter(p=>p.sway).forEach(p=>T.add({targets:p.sprite,scaleX:{from:p.scaleX*.992,to:p.scaleX*1.008},duration:1700+Math.random()*1500,yoyo:true,repeat:-1,ease:'Sine.easeInOut',delay:Math.random()*1300}));
    if(this.campfireProp)T.add({targets:this.campfireProp,scaleY:{from:this.campfireProp.scaleY*.98,to:this.campfireProp.scaleY*1.025},yoyo:true,duration:190+Math.random()*60,repeat:-1,ease:'Sine.easeInOut'});
    // Moinho de vento de Foosha: pás girando.
    const w=this.windmill,bl=this.add.graphics().setPosition(w.x,w.y).setDepth(-7);
    for(let k=0;k<4;k++){const a=k*Math.PI/2+.2,rot=(x,y)=>[x*Math.cos(a)-y*Math.sin(a),x*Math.sin(a)+y*Math.cos(a)];const P=[rot(10,3),rot(60,3),rot(60,16),rot(10,13)].map(([x,y])=>({x,y}));bl.fillStyle(0xf1e4c3);bl.fillPoints(P,true);bl.lineStyle(2,0x6b4a2e);bl.beginPath();bl.moveTo(0,0);const e=rot(62,0);bl.lineTo(e[0],e[1]);bl.strokePath();bl.lineStyle(1,0xb9a574);for(const f of [.35,.65]){const q1=rot(10+50*f,3),q2=rot(10+50*f,15);bl.beginPath();bl.moveTo(q1[0],q1[1]);bl.lineTo(q2[0],q2[1]);bl.strokePath();}}
    bl.fillStyle(0x4a3322);bl.fillCircle(0,0,7);bl.fillStyle(0xd7ad66);bl.fillCircle(0,0,3);
    this.blades=bl;T.add({targets:bl,angle:360,duration:9000,repeat:-1,ease:'Linear'});
    // Fumaça das chaminés.
    (this.chimneys||[]).forEach(c=>this.add.particles(c.x,c.y,'smoke',{lifespan:3400,frequency:700,speedY:{min:-26,max:-16},speedX:{min:4,max:13},scale:{start:.3,end:1.5},alpha:{start:.5,end:0},rotate:{min:0,max:360}}).setDepth(5));
    // Fogueira do acampamento: chamas tremulando, brilho, faíscas e fumaça.
    const fx=2165,fy=1375;
    this.fireGlow=this.add.image(fx,fy-10,'glow').setBlendMode(Phaser.BlendModes.ADD).setDepth(3).setAlpha(.5).setScale(1.5);
    T.add({targets:this.fireGlow,alpha:{from:.38,to:.7},scale:{from:1.35,to:1.75},duration:430,yoyo:true,repeat:-1,ease:'Sine.easeInOut'});
    [[0,1,0],[-10,.7,120],[10,.78,60]].forEach(([ox,sc,del])=>{const f=this.add.graphics().setPosition(fx+ox,fy).setDepth(4);f.fillStyle(0xf09a38);f.fillTriangle(-20,0,0,-40,20,0);f.fillStyle(0xffd45a);f.fillTriangle(-10,-1,0,-27,10,-1);f.setScale(sc);T.add({targets:f,scaleY:{from:sc*.82,to:sc*1.2},scaleX:{from:sc*.92,to:sc*1.06},duration:150+Math.random()*100,yoyo:true,repeat:-1,delay:del,ease:'Sine.easeInOut'});});
    this.add.particles(fx,fy-26,'spark',{lifespan:{min:700,max:1300},speedY:{min:-75,max:-35},speedX:{min:-20,max:20},scale:{start:1,end:0},alpha:{start:1,end:0},frequency:130,blendMode:'ADD'}).setDepth(11.42);
    this.add.particles(fx,fy-44,'smoke',{lifespan:3600,frequency:520,speedY:{min:-34,max:-22},speedX:{min:5,max:14},scale:{start:.35,end:1.7},alpha:{start:.5,end:0},rotate:{min:0,max:360},tint:0x9a9a9a}).setDepth(11.43);
    // Placa balançando do Party's Bar.
    (this.signs||[]).forEach(s=>{const c=this.add.container(s.x,s.y).setDepth(2);const bg=this.add.graphics();bg.fillStyle(0x4c3828);bg.fillRect(-27,0,54,13);bg.fillStyle(0xe4b75c);bg.fillRect(-25,2,50,9);bg.lineStyle(1,0x4c3828);bg.beginPath();bg.moveTo(-20,-6);bg.lineTo(-20,0);bg.moveTo(20,-6);bg.lineTo(20,0);bg.strokePath();const t=this.add.text(0,6.5,s.text,{fontFamily:'Trebuchet MS, sans-serif',fontSize:'8px',fontStyle:'bold',color:'#4a2c17'}).setOrigin(.5).setResolution(3);c.add([bg,t]);T.add({targets:c,angle:{from:-3.5,to:3.5},duration:1500,yoyo:true,repeat:-1,ease:'Sine.easeInOut'});});
    // Bandeiras ao vento (tecido redesenhado a cada frame em updateFx).
    this.flags=(this.flagDefs||[]).map(d=>Object.assign({g:this.add.graphics().setDepth(3)},d));
    // Capim balançando fora das trilhas.
    const nearRoad=(x,y)=>(this.roadLines||[]).some(r=>{for(let i=0;i<r.pts.length-1;i++){const [x1,y1]=r.pts[i],[x2,y2]=r.pts[i+1],dx=x2-x1,dy=y2-y1,l2=dx*dx+dy*dy||1;let t=((x-x1)*dx+(y-y1)*dy)/l2;t=Math.max(0,Math.min(1,t));if(Math.hypot(x-(x1+dx*t),y-(y1+dy*t))<r.w/2+24)return true;}return false;});
    let n=0;for(let tries=0;tries<2500&&n<120;tries++){const x=200+Math.random()*2550,y=270+Math.random()*1700;if(((x-410)/160)**2+((y-500)/105)**2<1)continue;if(x>1950&&x<2430&&y>1090&&y<1470)continue;if(nearRoad(x,y))continue;if(this.rects.some(r=>Math.abs(x-r.x)<r.w/2+28&&Math.abs(y-r.y)<r.h/2+28))continue;n++;const tf=this.add.image(x,y,'tuft').setOrigin(.5,1).setDepth(-7).setScale(1+Math.random()*.9);T.add({targets:tf,angle:{from:-7,to:7},duration:1000+Math.random()*1300,yoyo:true,repeat:-1,ease:'Sine.easeInOut',delay:Math.random()*1200});}
    // Folhas voando pela floresta.
    this.add.particles(0,0,'leaf',{x:{min:830,max:1790},y:{min:420,max:1480},lifespan:7000,frequency:520,speedX:{min:14,max:38},speedY:{min:6,max:20},rotate:{start:0,end:360},scale:{min:.8,max:1.3},alpha:{start:.95,end:0},tint:[0x7fb04a,0xc9b23c,0x5d9a47]}).setDepth(20);
    // Sombras de nuvens atravessando a ilha.
    for(let i=0;i<5;i++){const c=this.add.image(Math.random()*WW,300+i*400+Math.random()*120,'cloud').setDepth(-5).setAlpha(.5).setScale(1.2+Math.random()*1.4,1+Math.random()*.6);this.drift(c,1,95000+Math.random()*60000);}
    // Gaivotas sobre o mar.
    for(let i=0;i<5;i++){const dir=Math.random()<.5?1:-1;const gl=this.add.sprite(Math.random()*WW,26+Math.random()*100,'gull0').setDepth(40).setScale(2).setFlipX(dir<0);gl.play('gull_fly');gl.anims.setProgress(Math.random());T.add({targets:gl,y:gl.y+8,duration:1400+Math.random()*900,yoyo:true,repeat:-1,ease:'Sine.easeInOut'});this.drift(gl,dir,55000+Math.random()*30000);}
  }
  drawFlag(f,t){const g=f.g;g.clear();const n=10,sw=f.w/n;for(let i=0;i<n;i++){const k=i/(n-1),off=Math.sin(t/170+i*.75)*(1+k*3.2),h=f.h+Math.sin(t/230+i*.5)*k*1.2;g.fillStyle(i%2?f.c2:f.c1);g.fillRect(f.x+i*sw,f.y+off,sw+.6,h);}
    if(f.emblem){const i=5,k=i/(n-1),off=Math.sin(t/170+i*.75)*(1+k*3.2),cx=f.x+i*sw+sw/2,cy=f.y+off+f.h/2-1;g.fillStyle(0xf3e9d0);g.fillCircle(cx,cy,5.5);g.fillStyle(0x3a1a16);g.fillRect(cx-3,cy-2,2,2);g.fillRect(cx+1,cy-2,2,2);g.fillRect(cx-1,cy+2,2,1);}}
  updateFx(t,delta){
    this.waveA.tilePositionX+=delta*.014;this.waveA.tilePositionY=Math.sin(t/1300)*3;this.waveB.tilePositionX-=delta*.008;this.waveB.tilePositionY=Math.cos(t/1700)*2;this.foam.tilePositionX+=delta*.01;
    this.flags.forEach(f=>this.drawFlag(f,t));
  }
  initPlayerFx(){const p=this.player;p.shadow=this.add.image(p.x,p.y+24,'shadow').setDepth(shadowDepth(p.y+24)).setAlpha(.42).setScale(1.42);p.face='f';p.play('hero_f_idle');this.dust=this.add.particles(0,0,'puff',{lifespan:450,speed:{min:6,max:18},scale:{start:.7,end:0},alpha:{start:.45,end:0},emitting:false}).setDepth(8);p.lastDust=0;}
  animatePlayer(vx,vy){
    const p=this.player,now=this.time.now,moving=Math.hypot(vx,vy)>.1;
    p.shadow.setPosition(p.x,p.y+24).setDepth(shadowDepth(p.y+24));p.setDepth(worldDepth(p.y+23));
    if(now<(p.hurtUntil||0)){p.setTexture('hero_f_hurt');return;}
    if(now<(p.punchUntil||0)){const attackKey=p.activeAttackAnim||'hero_s_attack';if(p.anims.currentAnim?.key!==attackKey)p.play(attackKey,true);return;}
    if(now<(p.victoryUntil||0)){if(p.anims.currentAnim?.key!=='hero_f_victory_anim')p.play('hero_f_victory_anim');return;}
    if(moving){if(Math.abs(vx)>=Math.abs(vy)*.8){p.face='s';p.setFlipX(vx<0);}else{p.face=vy<0?'b':'f';p.setFlipX(false);}
      if(now-p.lastDust>230){p.lastDust=now;this.dust.emitParticleAt(p.x+(Math.random()-.5)*8,p.y+18,1);}}
    const key='hero_'+p.face+(moving?'_walk':'_idle');
    if(p.anims.currentAnim?.key!==key||!p.anims.isPlaying)p.play(key,true);
  }
  // Soco do Gomu Gomu: preparação, extensão, impacto e recuperação; o cálculo do dano ocorre no impacto.
  punchFx(e,n,onImpact=()=>{},style='basic'){
    const p=this.player;if(!p||!e||!e.active)return;const big=n>=p.atk*1.9;
    const ang=Math.atan2(e.y-p.y,e.x-p.x),dist=Math.hypot(e.x-p.x,e.y-p.y),len=Math.max(26,dist-8),right=e.x>=p.x;
    p.setFlipX(!right);p.punchUntil=this.time.now+(style==='bazuca'?420:style==='rapid'?200:220);p.activeAttackAnim=style==='bazuca'?'hero_s_bazuca':'hero_s_attack';p.punchStartedAt=this.time.now;p.play(p.activeAttackAnim,true);
    const slashCount=style==='bazuca'?3:1;
    for(let i=0;i<slashCount;i++){
      const offset=style==='bazuca'?(i-1)*.26:0;
      const slash=this.add.image(p.x+Math.cos(ang+offset)*Math.min(38,len*.28),p.y-5+Math.sin(ang+offset)*Math.min(24,len*.18),'fx_slash_blue')
        .setDepth(48+i*.01).setOrigin(.5,.5).setRotation(ang+offset+.5).setScale(.12,.18).setAlpha(.0).setFlipY(i%2===1);
      this.tweens.add({targets:slash,alpha:style==='bazuca'?.96:.82,scaleX:style==='bazuca'?1.03:.76,scaleY:style==='bazuca'?.82:.62,x:p.x+Math.cos(ang+offset)*Math.min(len*.62,86),y:p.y-4+Math.sin(ang+offset)*Math.min(len*.5,58),duration:style==='bazuca'?210:125,hold:style==='bazuca'?50:35,yoyo:true,ease:'Cubic.easeOut',onComplete:()=>slash.destroy()});
    }
    this.time.delayedCall(style==='bazuca'?245:105,()=>{if(e.active){this.impactFx(e.x,e.y,big||style==='bazuca');const d=Math.max(1,Math.hypot(e.x-p.x,e.y-p.y));e.knockUntil=this.time.now+(big||style==='bazuca'?260:130);e.kvx=(e.x-p.x)/d*(big||style==='bazuca'?280:150);e.kvy=(e.y-p.y)/d*(big||style==='bazuca'?280:150);e.hurtUntil=this.time.now+160;e.setTexture(e.skin+'_hit');onImpact();}});
  }
  impactFx(x,y,big){
    const s=this.add.image(x,y,'fx_impact_star').setDepth(50).setScale(big?.46:.29).setAngle(Math.random()*45);
    this.tweens.add({targets:s,scale:big?1.9:1.1,alpha:0,angle:s.angle+25,duration:big?280:200,ease:'Cubic.easeOut',onComplete:()=>s.destroy()});
    this.burst(x,y,'spark',big?10:5,{lifespan:380,speed:{min:50,max:140},blendMode:'ADD'},600);
    if(big){this.cameras.main.shake(130,.0035);this.floatText(x,y-34,this.pick(['DON!','BAM!','POW!']),{size:24,color:'#ffe36e',dur:800});}
  }
  hurtFx(e,dmg){
    const p=this.player;p.setTint(0xff6a6a);this.time.delayedCall(140,()=>{if(p.active)p.clearTint();});
    this.floatText(p.x,p.y-30,`-${dmg}`,{size:17,color:'#ff9c8f',stroke:'#3a0d0d'});this.cameras.main.shake(90,.0025);
    p.hurtUntil=this.time.now+150;p.setTexture('hero_f_hurt');this.tweens.add({targets:p,scaleX:p.scaleX*1.07,scaleY:p.scaleY*.94,duration:80,yoyo:true});
  }
  killFx(e){
    const x=e.x,y=e.y,p=this.player,dir=x>=p.x?1:-1;
    const gh=this.add.sprite(x,y,e.texture.key).setDepth(47).setFlipX(e.flipX).setScale(e.scaleX).setTint(0xffbbbb);
    this.tweens.add({targets:gh,x:x+dir*(e.boss?200:150),y:y-(e.boss?200:130),angle:dir*(540+Math.random()*360),duration:e.boss?820:650,ease:'Quad.easeOut',
      onComplete:()=>{this.burst(gh.x,gh.y,'sparkle',1,{lifespan:700,speed:0,scale:{start:1.8,end:.2},alpha:{start:1,end:0},rotate:{start:0,end:90},blendMode:'ADD'},900);gh.destroy();}});
    this.tweens.add({targets:gh,alpha:0,delay:380,duration:320});
    this.burst(x,y,'puff',7,{lifespan:420,speed:{min:20,max:70},scale:{start:1.1,end:0},alpha:{start:.7,end:0}},700);
    if(this.chaseTarget===e)this.chaseTarget=null;if(e.shadow)e.shadow.destroy();if(e.label)e.label.destroy();e.destroy();
  }
  coinFx(d){
    const y=d.y;d.setDepth(worldDepth(y));d.play('coin_spin');
    this.tweens.add({targets:d,y:y-26,duration:240,ease:'Quad.easeOut',yoyo:true,onComplete:()=>{if(d.active)this.tweens.add({targets:d,y:y-8,duration:140,yoyo:true,ease:'Quad.easeOut'});}});
    this.time.delayedCall(6800,()=>{if(d.active)this.tweens.add({targets:d,alpha:.2,duration:130,yoyo:true,repeat:5});});
  }
  levelFx(){
    const p=this.player;p.punchUntil=0;p.victoryUntil=this.time.now+650;p.setFlipX(false);p.play('hero_f_victory_anim',true);const r=this.add.image(p.x,p.y+8,'ring').setDepth(46).setScale(.3).setAlpha(.9);
    this.tweens.add({targets:r,scale:3.2,alpha:0,duration:700,ease:'Cubic.easeOut',onComplete:()=>r.destroy()});
    this.floatText(p.x,p.y-42,'NÍVEL UP!',{size:20,color:'#ffe36e',dur:1100,rise:40});
    this.burst(p.x,p.y,'sparkle',12,{lifespan:900,speed:{min:50,max:140},scale:{start:1.2,end:0},gravityY:60,blendMode:'ADD'},1200);
  }
  spawnFx(e){
    if(!this.booted)return;e.setAlpha(0);this.tweens.add({targets:e,alpha:1,duration:260});
    this.burst(e.x,e.y+14,'puff',6,{lifespan:450,speed:{min:15,max:50},scale:{start:1,end:0},alpha:{start:.6,end:0}},700);
  }
  animateEnemy(e,dx,d){
    const moving=e.body&&(Math.abs(e.body.velocity.x)+Math.abs(e.body.velocity.y)>5);
    if(Math.abs(dx)>6)e.setFlipX(dx<0);
    if(e.shadow)e.shadow.setPosition(e.x,e.y+(e.boss?31:25)).setDepth(shadowDepth(e.y+(e.boss?31:25)));
    e.setDepth(worldDepth(e.y+(e.boss?29:20)));
    if(this.time.now<(e.hurtUntil||0)){e.setTexture(e.skin+'_hit');return;}
    if(e.attacking){const key=e.skin+'_atk';if(e.anims.currentAnim?.key!==key||!e.anims.isPlaying)e.play(key,true);return;}
    const key=e.skin+(moving?'_walk':'_idle');
    if(e.anims.currentAnim?.key!==key||!e.anims.isPlaying)e.play(key,true);
  }
  enemyAttack(e){if(!e?.active||e.attacking||this.time.now<(e.nextAttackAt||0))return;e.attacking=true;e.nextAttackAt=this.time.now+(e.boss?1550:1180);e.setVelocity(0,0);e.play(e.skin+'_atk',true);const windup=e.boss?430:360;this.time.delayedCall(windup,()=>{if(!e.active)return;const p=this.player;const d=Phaser.Math.Distance.Between(p.x,p.y,e.x,e.y);if(d<(e.boss?82:68)){const dmg=Math.max(1,e.atk-(p.defense||0));this.enemyImpactFx(p.x,p.y,e.boss);p.hp-=dmg;this.hurtFx(e,dmg);if(p.hp<=0){p.hp=p.maxHp;p.xp=Math.floor(p.xp*.8);p.setPosition(410,460);this.auto=false;this.hud.querySelector('#auto').textContent='⚔ Caça OFF';this.hud.querySelector('#auto').classList.remove('active');this.saveProgress();this.toast('Você morreu! Perdeu 20% da XP atual.');}}});this.time.delayedCall(e.boss?920:760,()=>{if(e.active){e.attacking=false;if(e.anims) e.play(e.skin+'_idle',true);}});}
  enemyImpactFx(x,y,big=false){const flash=this.add.circle(x,y+4,big?31:20,0xe35b45,.38).setDepth(47);this.tweens.add({targets:flash,scale:big?1.5:1.3,alpha:0,duration:220,onComplete:()=>flash.destroy()});this.burst(x,y+5,'spark',big?8:4,{lifespan:260,speed:{min:35,max:90},blendMode:'ADD'},380);}
  drawHpBars(){
    const g=this.hpg||(this.hpg=this.add.graphics().setDepth(55));g.clear();
    this.enemies.getChildren().forEach(e=>{if(!e.active)return;
      if(e.label)e.label.setPosition(e.x,e.y-(e.boss?64:42));
      if(e.hp>=e.maxHp&&!e.boss)return;
      const w=e.boss?52:30,x=e.x-w/2,y=e.y-(e.boss?51:34),ratio=Math.max(0,e.hp/e.maxHp);
      g.fillStyle(0x1c1410,.9);g.fillRect(x-1,y-1,w+2,6);g.fillStyle(e.boss?0xe0a526:0xd8453b);g.fillRect(x,y,w*ratio,4);});
    const target=this.selectedEnemy?.active&&this.selectedEnemy.hp>0?this.selectedEnemy:null;const tg=this.targetGraphics||(this.targetGraphics=this.add.graphics().setDepth(46));tg.clear();if(target){tg.lineStyle(2,0xffdf78,.98);tg.strokeEllipse(target.x,target.y+17,target.boss?65:49,18);tg.fillStyle(0xffdf78,.9);tg.fillTriangle(target.x-5,target.y-40,target.x+5,target.y-40,target.x,target.y-31);}
  }
  onUI(p){return p.y>this.scale.height-125;}
  zoom(){return Math.min(this.scale.width/900,this.scale.height/560)*1.25;}
  update(_,delta){if(!this.player?.active)return;this.booted=true;this.updateFx(this.time.now,delta);if(Phaser.Input.Keyboard.JustDown(this.keyOne))this.gatling();
    this.regions.forEach(r=>{const alive=this.enemies.getChildren().filter(e=>e.active&&e.region===r.index).length;const cap=r.cap;if(alive<cap&&this.time.now>=r.spawnAt){this.spawnInRegion(r);r.spawnAt=this.time.now+r.respawn+Math.random()*1800;}});
    let vx=0,vy=0;const manual=(this.cursors.left.isDown||this.keys.A.isDown||this.cursors.right.isDown||this.keys.D.isDown||this.cursors.up.isDown||this.keys.W.isDown||this.cursors.down.isDown||this.keys.S.isDown||this.joy.active);
    if(manual){if(this.cursors.left.isDown||this.keys.A.isDown)vx--;if(this.cursors.right.isDown||this.keys.D.isDown)vx++;if(this.cursors.up.isDown||this.keys.W.isDown)vy--;if(this.cursors.down.isDown||this.keys.S.isDown)vy++;if(this.joy.active){vx=this.joy.dx;vy=this.joy.dy;}this.moveTarget=null;this.navGoal=null;this.chaseTarget=null;}
    else if(this.chaseTarget&&!this.auto&&this.chaseTarget.active&&this.chaseTarget.hp>0){const e=this.chaseTarget,d=Phaser.Math.Distance.Between(this.player.x,this.player.y,e.x,e.y);if(d>70){const v=this.followNavigation(e.x,e.y);vx=v.x;vy=v.y;}else{this.navGoal=null;this.moveTarget=null;if(this.time.now-this.lastAttack>420)this.attack();}}
    else if(this.auto){const se=this.selectedEnemy?.active&&this.selectedEnemy.hp>0&&(!this.huntArea||(this.selectedEnemy.x>=this.huntArea.x&&this.selectedEnemy.x<=this.huntArea.x+this.huntArea.w&&this.selectedEnemy.y>=this.huntArea.y&&this.selectedEnemy.y<=this.huntArea.y+this.huntArea.h))?this.selectedEnemy:null;const e=se||this.nearest(900,this.huntArea);if(e){const d=Phaser.Math.Distance.Between(this.player.x,this.player.y,e.x,e.y);if(d>48){const v=this.followNavigation(e.x,e.y);vx=v.x;vy=v.y;}else{this.navGoal=null;this.selectTarget(e);if(this.time.now-this.lastAttack>610){this.lastAttack=this.time.now;const close=this.enemies.getChildren().filter(q=>q.active&&q.hp>0&&Phaser.Math.Distance.Between(this.player.x,this.player.y,q.x,q.y)<140);if(close.length>=2&&this.time.now>=this.skillReadyAt){this.skillReadyAt=this.time.now+2600;this.punchFx(e,this.player.atk*2.25,()=>this.applyBazucaDamage(e,this.player.atk*2.25),'bazuca');}else this.damage(e,this.player.atk*(Math.random()*100<this.player.crit?2:1),'basic');}}}else{let target=null;if(this.huntArea){if(!this.routeTarget||Phaser.Math.Distance.Between(this.player.x,this.player.y,this.routeTarget.x,this.routeTarget.y)<35||!this.isWalkable(this.routeTarget.x,this.routeTarget.y,10)){let candidate=null;for(let tries=0;tries<20;tries++){const q={x:this.huntArea.x+Math.random()*this.huntArea.w,y:this.huntArea.y+Math.random()*this.huntArea.h};if(this.isWalkable(q.x,q.y,10)){candidate=q;break;}}this.routeTarget=candidate||{x:this.player.x+80,y:this.player.y+80};this.navGoal=null;}target=this.routeTarget;}else if(this.route.length){const p=this.routePoint();if(p)target=p;}else{if(!this.routeTarget||Phaser.Math.Distance.Between(this.player.x,this.player.y,this.routeTarget.x,this.routeTarget.y)<40){const r=this.regions.find(r=>this.player.x>=r.x1-150&&this.player.x<=r.x2+150&&this.player.y>=r.y1-150&&this.player.y<=r.y2+150)||this.regions[1];let q=null;for(let tries=0;tries<20;tries++){const pt=this.randomPoint(r);if(this.isWalkable(pt.x,pt.y,10)){q=pt;break;}}this.routeTarget=q||this.randomPoint(r);this.navGoal=null;}target=this.routeTarget;}if(target){const v=this.followNavigation(target.x,target.y);vx=v.x;vy=v.y;}}}
    else if(this.moveTarget){if(Phaser.Math.Distance.Between(this.player.x,this.player.y,this.moveTarget.x,this.moveTarget.y)<16){this.moveTarget=null;this.navGoal=null;}else{const v=this.followNavigation(this.moveTarget.x,this.moveTarget.y);vx=v.x;vy=v.y;}}
    const l=Math.hypot(vx,vy);if(l>1){vx/=l;vy/=l;}this.player.setVelocity(vx*150,vy*150);this.animatePlayer(vx,vy);
    this.enemies.getChildren().forEach(e=>{if(!e.active)return;const dx=this.player.x-e.x,dy=this.player.y-e.y,d=Math.hypot(dx,dy);if(this.time.now<(e.knockUntil||0)){e.setVelocity(e.kvx,e.kvy);}else if(d<150&&d>38&&!e.attacking){e.setVelocity(dx/d*e.speed,dy/d*e.speed);}else e.setVelocity(0,0);this.animateEnemy(e,dx,d);if(d<39)this.enemyAttack(e);});
    this.drawHpBars();this.drops.getChildren().forEach(d=>{if(Phaser.Math.Distance.Between(this.player.x,this.player.y,d.x,d.y)<24){d.destroy();this.toast('+1 moeda');}});
    this.hud.querySelector('#lvl').textContent=`LV ${this.player.level}`;this.hud.querySelector('#hp').textContent=`HP ${Math.max(0,this.player.hp)}/${this.player.maxHp}`;this.hud.querySelector('#xp').textContent=`XP ${this.player.xp}/${this.player.nextXp}`;this.hud.querySelector('#kills').textContent=`KOs ${this.kills||0}`;const hpfill=this.hud.querySelector('#hpfill'),xpfill=this.hud.querySelector('#xpfill');if(hpfill)hpfill.style.width=`${Math.max(0,Math.min(100,this.player.hp/this.player.maxHp*100))}%`;if(xpfill)xpfill.style.width=`${Math.max(0,Math.min(100,this.player.xp/this.player.nextXp*100))}%`;this.hud.querySelector('#zoneinfo').textContent=`Mobs ativos: ${this.enemies.getChildren().filter(e=>e.active).length} · respawn contínuo`;this.renderBattlePanel();this.updateSkillButtons();if(this.time.now%300<delta)this.renderMap();if(this.hud.querySelector('#charactermodal')&&!this.hud.querySelector('#charactermodal').hidden)this.renderCharacter();this.hud.querySelector('#zone').textContent=this.player.x<700?'Vila Foosha':this.player.x<1900?'Floresta do Monte Colubo':'Acampamento dos Bandidos';
  }
}
new Phaser.Game({type:Phaser.AUTO,parent:'game',backgroundColor:'#6b9b4e',pixelArt:false,roundPixels:false,scale:{mode:Phaser.Scale.RESIZE,width:innerWidth,height:innerHeight},physics:{default:'arcade',arcade:{debug:false}},scene:[Island]});
